# Security & Datenverarbeitung

Dieses Repository ist ein **Prototyp** für eigene Garmin-Gesundheitsdaten; nicht als öffentlicher Mehrbenutzer-Dienst betreiben.

- Repository privat halten und 2FA für GitHub aktivieren.
- Alle Garmin-Zugangsdaten und Tokens ausschließlich lokal/in Secret-Managern verwahren.
- Token nie in Issues, Pull Requests, Logs oder Screenshots ablegen.
- `data/`, `app/data/`, `.env`, `.venv/`, FIT/GPX sowie Schlüsseldateien sind in `.gitignore` ausgeschlossen.
- Watch-Upload-Token ist kein vollwertiger Account-Login. Die aktuelle `Config.mc` setzt nach lokaler Anpassung einen Token im Code voraus; daher ein beschränktes Token verwenden und **nicht** in Git einchecken. Für eine produktive App ist eine andere Secret-Provisionierung nötig.
- Ein öffentlich erreichbarer Server braucht TLS, Rate Limits, Benutzerauthentifizierung, Zugriffskontrolle, Sicherung und ein Lösch-/Exportkonzept.
- Eigene Scores haben keine klinische Validierung und dürfen nicht als medizinische Diagnose verwendet werden.
- Security-Vorfälle bitte nicht mit echten Gesundheitsdaten in öffentlich sichtbaren Issues dokumentieren.
