-- PostgreSQL 16+ target architecture, NOT executed by the local JSON prototype.
-- Health data security and Row Level Security policies must be added before deployment.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE account_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 created_at timestamptz NOT NULL DEFAULT now(),
 display_timezone text NOT NULL DEFAULT 'Europe/Berlin',
 is_active boolean NOT NULL DEFAULT true
);
CREATE TABLE source_accounts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 provider text NOT NULL CHECK(provider IN ('garmin_personal','garmin_business','connect_iq','manual','apple_health','other')),
 external_account_hash text, status text NOT NULL DEFAULT 'pending',
 secret_vault_ref text, connected_at timestamptz,
 UNIQUE(user_id,provider,external_account_hash)
);
CREATE TABLE user_devices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 source_account_id uuid REFERENCES source_accounts(id),
 model text, firmware text, device_alias text,
 device_fingerprint_hash text,
 last_seen_at timestamptz,
 UNIQUE(user_id,device_fingerprint_hash)
);
CREATE TABLE raw_ingest_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 source_account_id uuid REFERENCES source_accounts(id),
 provider_record_id text,
 source_category text NOT NULL,
 source_api_schema_version text,
 record_hash text NOT NULL,
 source_observed_at timestamptz,
 imported_at timestamptz NOT NULL DEFAULT now(),
 storage_object_ref text NOT NULL, -- encrypted object store ref; avoid plaintext here
 status text NOT NULL DEFAULT 'pending',
 error_code text,
 UNIQUE(user_id,source_category,record_hash)
);
CREATE TABLE observations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 device_id uuid REFERENCES user_devices(id),
 raw_event_id uuid REFERENCES raw_ingest_events(id),
 metric_key text NOT NULL,
 value_num double precision,
 value_text text,
 unit text,
 measured_at timestamptz NOT NULL,
 measured_until timestamptz,
 local_date date,
 quality text NOT NULL CHECK(quality IN ('valid','estimated','stale','missing','conflict','invalid')),
 source_revision integer NOT NULL DEFAULT 1,
 UNIQUE(user_id,metric_key,measured_at,raw_event_id)
);
CREATE INDEX observations_user_metric_time ON observations(user_id,metric_key,measured_at DESC);
CREATE TABLE sleep_sessions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 raw_event_id uuid REFERENCES raw_ingest_events(id),
 wake_date date NOT NULL,
 sleep_start timestamptz NOT NULL,
 sleep_end timestamptz NOT NULL,
 actual_sleep_seconds integer,
 in_bed_seconds integer,
 primary_sleep boolean NOT NULL DEFAULT true,
 CHECK(sleep_end>sleep_start)
);
CREATE TABLE sleep_stages (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 sleep_session_id uuid NOT NULL REFERENCES sleep_sessions(id) ON DELETE CASCADE,
 stage text NOT NULL CHECK(stage IN ('awake','light','deep','rem','unknown')),
 stage_start timestamptz NOT NULL,
 stage_end timestamptz NOT NULL,
 CHECK(stage_end>stage_start)
);
CREATE TABLE activities (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 raw_event_id uuid REFERENCES raw_ingest_events(id),
 provider text NOT NULL,
 provider_activity_id text,
 activity_type text,
 started_at timestamptz NOT NULL,
 ended_at timestamptz NOT NULL,
 duration_seconds integer,
 zone_seconds integer[],
 distance_m double precision,
 activity_kcal double precision,
 CHECK(ended_at>=started_at),
 UNIQUE(user_id,provider,provider_activity_id)
);
CREATE TABLE exercise_sets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 activity_id uuid REFERENCES activities(id) ON DELETE CASCADE,
 exercise_id text NOT NULL,
 set_ordinal integer NOT NULL,
 set_type text NOT NULL DEFAULT 'working',
 reps integer,
 weight_kg numeric(9,3),
 rir numeric(4,1),
 rpe numeric(4,1),
 duration_seconds integer,
 logged_at timestamptz NOT NULL,
 CHECK(reps IS NULL OR reps BETWEEN 0 AND 500),
 CHECK(weight_kg IS NULL OR weight_kg BETWEEN 0 AND 1000)
);
CREATE TABLE food_logs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 logged_at timestamptz NOT NULL,
 food_name text NOT NULL,
 portion_g numeric(10,2),
 energy_kcal numeric(10,2),
 protein_g numeric(10,2), fat_g numeric(10,2), carbs_g numeric(10,2),
 source text NOT NULL DEFAULT 'manual', revision integer NOT NULL DEFAULT 1
);
CREATE TABLE journal_entries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 logged_at timestamptz NOT NULL,
 category text NOT NULL,
 value jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE score_snapshots (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES account_users(id) ON DELETE CASCADE,
 wake_date date NOT NULL,
 algorithm_version text NOT NULL,
 data_revision integer NOT NULL,
 computed_at timestamptz NOT NULL DEFAULT now(),
 values_json jsonb NOT NULL,
 missing_data_json jsonb NOT NULL DEFAULT '[]'::jsonb,
 confidence text NOT NULL DEFAULT 'unvalidated',
 UNIQUE(user_id,wake_date,algorithm_version,data_revision)
);
CREATE TABLE ingestion_jobs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 source_account_id uuid NOT NULL REFERENCES source_accounts(id) ON DELETE CASCADE,
 job_type text NOT NULL,
 window_start timestamptz, window_end timestamptz,
 state text NOT NULL DEFAULT 'queued',
 attempts integer NOT NULL DEFAULT 0,
 next_run_at timestamptz NOT NULL DEFAULT now(),
 last_error_code text
);
CREATE TABLE audit_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid REFERENCES account_users(id) ON DELETE SET NULL,
 event_type text NOT NULL,
 occurred_at timestamptz NOT NULL DEFAULT now(),
 event_metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);
-- Before real deployment: add user-scoped RLS policies, identity mapping,
-- transaction-safe ingest, backfill migration, vault integration and deletion service.
