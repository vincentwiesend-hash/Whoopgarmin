# PulseForge Garmin Lab — technische Bevel-Funktionsanalyse & eigenständiger Nachbau

**Abgleich: 28.10.2026. Status: Garmin-zentrierter, lokaler Demonstrator, keine fertige Bevel- oder NOOP-Kopie.**

Dieser Quellcode ist ausdrücklich **kein dekompilierter oder abgegriffener Bevel-Code**. Er dient dazu, öffentlich dokumentierte Funktionen einer Recovery-/Training-App sauber und nachvollziehbar für Garmin fēnix nachzubauen. Die Scores sind **eigene experimentelle Beispielmodelle**. Ohne reale Nutzer- und Garmin-Daten gibt es keinen end-to-end-Test mit Garmin Connect.

## Neu: Abgleich mit NOOP

Das vom Nutzer gelieferte Archiv `noop-main.zip` beschreibt eine andere Hardwarewelt (**WHOOP 4/5 via Bluetooth**) und umfangreiche lokale Analytics. Die neue Version übernimmt **nicht** den WHOOP-Bluetooth-Code. Stattdessen wurden seine am besten zu Garmin passenden Konzepte **eigenständig** als JavaScript ergänzt: 10 Metriken, fehlertolerante 7-/14-/28-/42-/90-Tage-Trends, Metrikvergleich mit Pearson-r, deskriptive Wochenänderungen, Datenabdeckung und ein Snapshot des letzten Connect-IQ-Uploads.

Vollständige Entscheidungstabelle: [`docs/09-noop-vs-pulseforge.md`](docs/09-noop-vs-pulseforge.md).

**Kein Drittanbieter-Quellcode/Asset wurde aus dem NOOP-Archiv in dieses Repository kopiert.** Im Archiv lag keine explizite Lizenzdatei. Gleichlautende Funktionen sind unabhängig implementiert; ursprüngliche Herstelleralgorithmen bleiben unbekannt.

## Inhalt

- `docs/01-bevel-inventory.md`: umfangreiche Funktionsinventur mit Belegstatus und Lücken.
- `docs/02-architecture.md`: Datenfluss, Garmin-Konnektoren, Datenqualität, Synchronisation.
- `docs/03-scoring.md`: reale Bevel-Dokumentation versus **eigene** Formeln und Testprotokoll.
- `docs/04-data-api.md`: kanonisches Datenmodell, REST-API, Postgres-Konzept.
- `docs/05-ux.md`: Screens, Navigationsstruktur, UX-Ereignisse, Garmin-Uhr.
- `docs/06-privacy-security.md`: sensible Gesundheitsdaten, GDPR/DSGVO, Security.
- `docs/07-roadmap-and-validation.md`: priorisierte Umsetzung, Black-Box-Validierung.
- `docs/08-sources.md`: datierte offizielle Primärquellen.
- `docs/09-noop-vs-pulseforge.md`: detaillierter NOOP/PulseForge-Abgleich mit Integrationsentscheidungen.
- `app/`: Node.js-Backend **ohne Fremdbibliotheken**, separierte Secrets, Authentifizierung, Tagesimport, Connect-IQ-Ingest, berechenbare Scores, responsives Browser-Dashboard inkl. echten Trends, Korrelation, Wochenvergleichen, Watch-Snapshot und Unit-Tests.
- `watch/`: weiterentwickelbare Connect-IQ-Quelle aus dem vorigen fēnix-Projekt. **Noch nicht mit Garmin-SDK kompiliert**.
- `garmin-import/`: Script mit **offiziellem Garmin Python SDK** für Authentifizierung und Rohdatenexport (Schlaf, HRV, Herzfrequenz, Tagesübersicht, Body Battery, Stress).
- `database/`: relationales Vorschlagsmodell für spätere Migration.

## Start: lokales Dashboard

Node.js >= 20 vorausgesetzt:

```bash
cd app
export READ_TOKEN="$(openssl rand -hex 32)"
export ADMIN_TOKEN="$(openssl rand -hex 32)"
export INGEST_TOKEN="$(openssl rand -hex 32)"
# Diese drei Werte sichern – in einem separaten Terminal sonst erneut setzen.
npm test
node server.mjs
# http://127.0.0.1:3477
```

Das Dashboard startet mit **ausdrücklich fiktiven Demonstrationsdaten**, damit du das UI prüfen kannst. Es zeigt keine echten persönlichen Werte ohne den oben gesetzten READ_TOKEN und einen echten Tagesimport. Die Demo-Trendkurve ist ein Platzhalter.

### Neue Analytics-Schnittstelle

Mit demselben Read-Token:

```bash
curl -H "X-Read-Token: $READ_TOKEN" \
  'http://127.0.0.1:3477/api/v1/analytics?days=28&first=hrv&second=rhr'
```

Ausgabe: `series` mit echten täglichen Kennzahlen (bei Datenlücken `null`), `comparison` mit `r` und Anzahl gemeinsamer Werte, `insights` (nur bei ausreichender Datenlage), sowie `coverage`. Unterstützte Zeitfenster sind 7, 14, 28, 42 und 90 Tage. Die Web-Oberfläche fragt für die interaktiven Darstellungen eine 90-Tage-Historie ab. **Korrelation ist keine Kausalität.**

### Echte Tagesdaten importieren

`POST /api/v1/days` nimmt **normalisierte, explizit bestätigte** Werte entgegen (nicht rohe, unvalidierte Garmin-Antworten):

```bash
curl -X POST http://127.0.0.1:3477/api/v1/days \
 -H "X-Admin-Token: $ADMIN_TOKEN" -H 'Content-Type: application/json' \
 -d '{"date":"2026-10-28","sources":["garmin-personal/manual-mapped"],"sleep":{"asleepMinutes":456,"inBedMinutes":487},"night":{"hrvRmssdMs":52,"restingHeartRateBpm":51},"garmin":{"bodyBattery":72,"stress":23,"steps":7800},"workouts":[]}'

curl -H "X-Read-Token: $READ_TOKEN" http://127.0.0.1:3477/api/v1/summary
```

Auch wenn die Tagesdaten vollständig sind, bleibt Recovery **bis zu 14 Tage mit nutzbarer Historie** leer; dies ist absichtlich und kein Bug.

### Garmin Personal API: echte Rohdaten exportieren

Dies ist die **empfohlene Hauptanbindung für private Nutzung**. In Garmin Connect Web einen eigenen Personal API Key erstellen (Details in Dokumentation), dann:

```bash
cd garmin-import
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export GARMIN_PERSONAL_API_KEY='DEIN_PRIVATER_GARMIN_KEY'
python fetch_personal.py --start 2026-10-01 --end 2026-10-28
python inspect_shapes.py ../data/raw/garmin/2026-10-28/sleep.json
```

*Schlüssel nicht in der Shell-History speichern, nicht in Git einchecken. Das Beispiel zeigt nur die Verwendung; empfohlen ist die Datei-Variante des offiziellen Garmin-Clients mit restriktiven Dateirechten. Datumsparameter anpassen.*

**Entscheidende Validierungsschranke:** Die Garmin-Rohdatenformate werden erst **nach einem ersten echten Abruf** auf dein Konto/Modell gemappt. Der Exporter erzeugt keine kanonischen Kennzahlen und behauptet keine unbestätigte Zuordnung. `inspect_shapes.py` gibt nur Feldnamen, keine Werte aus. Danach werden Mapping-Fixtures mit konkreten Einheiten und Quellnachweisen festgelegt, bevor Daten in `/api/v1/days` übernommen werden. Ohne Garmins API Key ist dies nicht ausführbar.

### Uhren-Upload aktivieren

`watch/source/Config.mc` benötigt deinen öffentlich erreichbaren **HTTPS**-Empfänger (mit Pfad `/api/garmin/ingest`) und einen auf Upload begrenzten **INGEST_TOKEN**. Das Watch-Quellprojekt stammt aus unserem vorherigen fēnix-Gerüst, muss mit dem Connect IQ SDK und der **exakten Gerätekennung** getestet werden. Es ist kein belegter, dauerhaft laufender Livestream.

## Was läuft bereits / was nicht?

**Läuft lokal und wurde getestet:** Node-API, Tokenprüfung, JSON-Parsing, einfache private lokale Speicherung, Score-Engine, fehlertolerante Kalibrierung, berechnete Trends und Vergleiche, Demo-Web-Dashboard, Testfälle. Kein vollwertiger Offline-Garmin-Direktzugang: Garmin-Connect-Import benötigt Internet.

**Ausgeliefert, aber extern ungetestet:** Garmin Personal API Export (benötigt persönlichen Key, Python-Abhängigkeit und Netzzugriff); Monkey-C-Quellprojekt (benötigt Connect-IQ-SDK und Uhr).

**Dokumentiert, aber noch nicht implementiert:** automatisches validiertes Roh-Garmin-Mapping, FIT-Parser, kompletter Krafttrainingseditor, Nutrition, Journal, medizinische Dokumente, ML-Biological-Age, KI-Coach, Login/Mehrbenutzerbetrieb, vollständige produktive DSGVO-Infrastruktur und anpassbare Trainingspläne auf die Uhr.

Es gibt **keine** Zusage, dass eigene Scores den Bevel-Werten entsprechen oder klinische Entscheidungen erlauben. Garmin Body Battery bleibt als eigener, klar bezeichneteter Garmin-Messwert getrennt von Bevels Energy Bank.

## Freigabehinweis

Bevel-Name und -Marke werden nur als Referenz verwendet. UI, Texte, Assets und eigener Source Code sollten für ein eigenes Produkt eigenständig entwickelt werden. Keine Drittanbieter-Zugangsdaten oder verdeckte App-Schnittstellen umgehen. Garmin Personal API ist **nur für private eigene Daten**, für fremde Nutzer wird Garmins Business/Developer-Programm benötigt.

## GitHub Repository

Dieser Quellcode kann in [`vincentwiesend-hash/Whoopgarmin`](https://github.com/vincentwiesend-hash/Whoopgarmin) veröffentlicht werden. **Dieses Ziel-Repository ist öffentlich.** Die Anleitung steht in [PUBLISH_TO_GITHUB.md](PUBLISH_TO_GITHUB.md); der CI-Workflow in `.github/workflows/ci.yml`. Ausschließlich Quellcode und synthetische Testdaten dürfen öffentlich sein. Garmin-Gesundheitsdaten und Zugangsdaten bleiben privat.
