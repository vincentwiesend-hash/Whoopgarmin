#!/usr/bin/env bash
# Usage: ./build.sh fenix7 ~/.garmin-developer-key.der
set -euo pipefail
if [[ "$#" -ne 2 ]]; then
  echo 'Usage: ./build.sh DEVICE_ID /path/to/developer_key.der' >&2
  exit 2
fi
cd "$(dirname "$0")"
command -v monkeyc >/dev/null || { echo 'Garmin Connect IQ SDK missing: monkeyc not found' >&2; exit 1; }
mkdir -p bin
monkeyc -f monkey.jungle -d "$1" -y "$2" -o "bin/garmin-bridge-$1.prg"
echo "Built: watch/bin/garmin-bridge-$1.prg"
