// Before compiling: configure your HTTPS URL and the limited upload token.
// Never embed the READ_TOKEN, Garmin credentials, or other master secrets here.
(:background)
module BridgeConfig {
    const ENDPOINT = "https://your-domain.example/api/garmin/ingest";
    const INGEST_TOKEN = "CHANGE_ME_TO_A_LONG_RANDOM_UPLOAD_TOKEN";
    // Your private identifier for distinguishing a device at the receiver.
    const DEVICE_ID = "fenix-main";
}
