import Toybox.ActivityMonitor;
import Toybox.Communications;
import Toybox.SensorHistory;
import Toybox.System;
import Toybox.Time;

// Shared by foreground app and background service: stay below background memory limits.
(:background)
module Uploader {
    (:background)
    function putSample(payload, valueKey, timeKey, iter) {
        if (iter == null) { return; }
        var sample = iter.next();
        if (sample != null && sample.data != null && sample.when != null) {
            payload.put(valueKey, sample.data);
            payload.put(timeKey, sample.when.value());
        }
    }

    (:background)
    function sampleHistory(payload) {
        var options = {
            :period => 1,
            :order => SensorHistory.ORDER_NEWEST_FIRST
        };
        try {
            if (SensorHistory has :getHeartRateHistory) {
                putSample(payload, "heart_rate_bpm", "heart_rate_at",
                          SensorHistory.getHeartRateHistory(options));
            }
        } catch (ex) { /* Value absent on device or during this run. */ }
        try {
            if (SensorHistory has :getBodyBatteryHistory) {
                putSample(payload, "body_battery", "body_battery_at",
                          SensorHistory.getBodyBatteryHistory(options));
            }
        } catch (ex) { }
        try {
            if (SensorHistory has :getStressHistory) {
                putSample(payload, "stress", "stress_at",
                          SensorHistory.getStressHistory(options));
            }
        } catch (ex) { }
        try {
            if (SensorHistory has :getOxygenSaturationHistory) {
                putSample(payload, "spo2_percent", "spo2_at",
                          SensorHistory.getOxygenSaturationHistory(options));
            }
        } catch (ex) { }
    }

    (:background)
    function makePayload() {
        var stats = System.getSystemStats();
        var payload = {
            "source" => "connect_iq",
            "device_id" => BridgeConfig.DEVICE_ID,
            "timestamp" => Time.now().value(),
            "battery_percent" => stats.battery
        };

        try {
            var monitor = ActivityMonitor.getInfo();
            if (monitor != null) {
                if (monitor.steps != null) {
                    payload.put("steps_today", monitor.steps);
                }
                if (monitor.stepGoal != null) {
                    payload.put("steps_goal", monitor.stepGoal);
                }
                if (monitor.calories != null) {
                    payload.put("calories_today_kcal", monitor.calories);
                }
                if (monitor.distance != null) {
                    payload.put("distance_today_cm", monitor.distance);
                }
                if (monitor.floorsClimbed != null) {
                    payload.put("floors_climbed_today", monitor.floorsClimbed);
                }
                try {
                    if (monitor.respirationRate != null) {
                        payload.put("respiration_bpm", monitor.respirationRate);
                    }
                } catch (ex) { }
                try {
                    if (monitor.timeToRecovery != null) {
                        payload.put("recovery_hours", monitor.timeToRecovery);
                    }
                } catch (ex) { }
            }
        } catch (ex) { }
        sampleHistory(payload);
        return payload;
    }

    // callback: (responseCode, responseData), negative codes indicate network errors.
    (:background)
    function send(callback) {
        var options = {
            :method => Communications.HTTP_REQUEST_METHOD_POST,
            :headers => {
                "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                "X-Device-Token" => BridgeConfig.INGEST_TOKEN
            },
            :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
        };
        Communications.makeWebRequest(BridgeConfig.ENDPOINT, makePayload(), options, callback);
    }
}
