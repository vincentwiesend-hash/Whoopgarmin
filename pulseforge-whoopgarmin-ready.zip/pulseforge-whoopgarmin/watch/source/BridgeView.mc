import Toybox.Graphics;
import Toybox.WatchUi;

class BridgeView extends WatchUi.View {
    var mStatus;

    function initialize() {
        View.initialize();
        mStatus = "Bereit";
    }

    function onShow() {
        mStatus = "Sende ...";
        WatchUi.requestUpdate();
        try {
            Uploader.send(method(:onUpload));
        } catch (ex) {
            mStatus = "Netzwerkfehler";
            WatchUi.requestUpdate();
        }
    }

    function onUpload(code, data) {
        if (code >= 200 && code < 300) {
            mStatus = "Upload OK";
        } else {
            mStatus = "HTTP/Netz: " + code;
        }
        WatchUi.requestUpdate();
    }

    function onUpdate(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(w / 2, h * 0.28, Graphics.FONT_MEDIUM,
                    "Garmin Bridge", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(w / 2, h * 0.50, Graphics.FONT_SMALL,
                    mStatus, Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(w / 2, h * 0.67, Graphics.FONT_XTINY,
                    "Upload beim Oeffnen", Graphics.TEXT_JUSTIFY_CENTER);
    }
}
