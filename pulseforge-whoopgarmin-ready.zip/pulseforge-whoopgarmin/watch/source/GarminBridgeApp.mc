import Toybox.Application;
import Toybox.Background;
import Toybox.System;
import Toybox.Time;

(:background)
class GarminBridgeApp extends Application.AppBase {
    function initialize() {
        AppBase.initialize();
    }

    function onStart(state) {
        try {
            // Request periodic work. The OS can defer or skip an execution.
            if (Background.getTemporalEventRegisteredTime() == null) {
                Background.registerForTemporalEvent(new Time.Duration(15 * 60));
            }
        } catch (ex) {
            System.println("Background unavailable: " + ex);
        }
    }

    function getInitialView() {
        return [new BridgeView()];
    }

    (:background)
    function getServiceDelegate() {
        return [new BridgeServiceDelegate()];
    }
}

(:background)
class BridgeServiceDelegate extends System.ServiceDelegate {
    function initialize() {
        ServiceDelegate.initialize();
    }

    function onTemporalEvent() {
        try {
            Uploader.send(method(:onUpload));
        } catch (ex) {
            Background.exit(-1);
        }
    }

    function onUpload(code, data) {
        Background.exit(code);
    }
}
