#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v gh >/dev/null 2>&1; then
  echo "GitHub CLI (gh) fehlt. Installation: https://cli.github.com/" >&2
  exit 2
fi
if ! gh auth status >/dev/null 2>&1; then
  echo "Bitte mit 'gh auth login' bei deinem GitHub-Konto anmelden." >&2
  exit 2
fi
if ! git rev-parse --verify main >/dev/null 2>&1; then
  echo "Fehler: Dieses Archiv enthält keinen Git-Commit auf main." >&2
  exit 2
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo "Nicht eingecheckte Änderungen vorhanden. Erst prüfen/committen." >&2
  exit 2
fi
if git remote get-url origin >/dev/null 2>&1; then
  echo "Remote origin existiert bereits: $(git remote get-url origin)" >&2
  echo "Bitte auf das richtige Repository prüfen und manuell 'git push -u origin main' ausführen." >&2
  exit 2
fi
# PRIVAT by default: Garmin/health projects must not be public by accident.
gh repo create pulseforge-garmin-lab --private --source . --remote origin --push
printf '\nErstellt. Bitte Sichtbarkeit im Browser prüfen (PRIVATE).\n'
