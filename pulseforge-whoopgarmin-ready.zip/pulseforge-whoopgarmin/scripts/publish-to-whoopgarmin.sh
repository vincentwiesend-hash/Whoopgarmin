#!/usr/bin/env bash
# Safely publish the source tree to an EXISTING GitHub repo.
# Preserves the remote commit history and refuses to force-push.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_REPO="${PULSEFORGE_TARGET_REPO:-https://github.com/vincentwiesend-hash/Whoopgarmin.git}"
TARGET_BRANCH="main"

command -v git >/dev/null || { echo "Fehler: Git fehlt." >&2; exit 2; }
if [ ! -d "$PROJECT_DIR/app" ] || [ ! -f "$PROJECT_DIR/README.md" ]; then
  echo "Fehler: Der vollständige PulseForge-Projektordner fehlt." >&2
  exit 2
fi

if [[ "$TARGET_REPO" == "https://github.com/vincentwiesend-hash/Whoopgarmin.git" ]]; then
  echo "Ziel: https://github.com/vincentwiesend-hash/Whoopgarmin"
  echo "Achtung: Dieses Repository ist öffentlich. Es werden ausschließlich die im Quellprojekt erfassten Dateien übertragen."
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

git clone --quiet --single-branch --branch "$TARGET_BRANCH" "$TARGET_REPO" "$TMP/target"
# Stage only known, tracked source files; no user health records, .env files, caches or keys.
# When distributing as a ZIP without .git, the shipped filelist is used instead.
if [ -d "$PROJECT_DIR/.git" ] && git -C "$PROJECT_DIR" -c "safe.directory=$PROJECT_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "$PROJECT_DIR" -c "safe.directory=$PROJECT_DIR" ls-files -z > "$TMP/filelist"
else
  if [ ! -f "$PROJECT_DIR/.publish-filelist" ]; then
    echo "Fehler: .publish-filelist fehlt. Bitte das vollständige ZIP entpacken." >&2
    exit 2
  fi
  cp "$PROJECT_DIR/.publish-filelist" "$TMP/filelist"
fi

COUNT=0
while IFS= read -r -d '' REL; do
  case "$REL" in
    ''|/*|*'..'*|.git/*|*/.git/*|*.env|*.pem|*.key|*.p12|*.pfx|*.der|*.fit|*.gpx|data/*|app/data/*)
      echo "Unsicherer Dateipfad in der Liste: $REL" >&2
      exit 3 ;;
  esac
  SRC="$PROJECT_DIR/$REL"
  if [[ ! -f "$SRC" || -L "$SRC" ]]; then
    echo "Ungültiger Quelldateipfad: $REL" >&2
    exit 3
  fi
  mkdir -p "$(dirname "$TMP/target/$REL")"
  cp "$SRC" "$TMP/target/$REL"
  COUNT=$((COUNT + 1))
done < "$TMP/filelist"

if [ "$COUNT" -lt 30 ]; then
  echo "Abbruch: Zu wenige Projektdateien ($COUNT)." >&2
  exit 3
fi

git -C "$TMP/target" add -A
git -C "$TMP/target" diff --cached --check
if git -C "$TMP/target" diff --cached --quiet; then
  echo "Keine Änderungen: Ziel-Repository ist bereits aktuell."
  exit 0
fi

git -C "$TMP/target" commit -m "Publish PulseForge Garmin and NOOP-inspired analytics" > /dev/null
git -C "$TMP/target" push origin "HEAD:$TARGET_BRANCH"
echo "Erfolgreich veröffentlicht: $COUNT Projektdateien in $TARGET_BRANCH."
