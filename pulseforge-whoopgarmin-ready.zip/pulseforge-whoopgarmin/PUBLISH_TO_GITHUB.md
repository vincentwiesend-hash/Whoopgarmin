# In das bestehende Repository `Whoopgarmin` veröffentlichen

**Ziel:** `https://github.com/vincentwiesend-hash/Whoopgarmin`
**Sichtbarkeit:** **ÖFFENTLICH** (Stand 28.10.2026)

Die ChatGPT-GitHub-Verbindung hat derzeit keinen Git-Schreibzugriff (403). Lokal kann der Code trotzdem mit dem bestehenden GitHub-Konto hochgeladen werden.

## Voraussetzungen

- Git ist installiert und `git push` nach GitHub funktioniert (z. B. via Git Credential Manager oder SSH).
- Git-Nutzername und E-Mail sind in `git config --global user.name` und `git config --global user.email` eingerichtet.
- Das ZIP vollständig entpacken und im Projektverzeichnis folgende Befehle ausführen:

```bash
bash scripts/publish-to-whoopgarmin.sh
```

Das Script klont den aktuellen Stand des Ziel-Repositories, übernimmt die explizit erfassten Projektdateien, erstellt einen neuen Commit und pusht **ohne Force-Push** nach `main`. Der bestehende Git-Verlauf bleibt erhalten. Bereits vorhandene zusätzliche Dateien werden nicht entfernt. `README.md` des Ziel-Repositories wird durch die ausführliche Projekt-README ersetzt. Das Script pusht **keine** geheimen `.env`-Dateien, Zugangsdaten oder realen Gesundheitsdaten. GitHub kann nach persönlichen Anmeldedaten fragen: Niemals Zugangstoken in einen Chat kopieren.

Falls Branch-Protection oder fehlende Berechtigungen das Pushen verbieten, bricht der Befehl ab und du kannst die Fehlermeldung prüfen. Dann GitHub-Kontozugang überprüfen.

## Sicherheit

Vor Veröffentlichung selbst sicherstellen, dass ausschließlich synthetische Testdaten vorliegen. `npm test` im Ordner `app/` führt die Tests aus. Ein Gerätetest mit der fēnix und ein echter Garmin-Personal-API-Test sind bisher nicht erfolgt.
