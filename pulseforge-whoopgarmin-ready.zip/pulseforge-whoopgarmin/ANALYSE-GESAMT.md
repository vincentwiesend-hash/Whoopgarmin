# Bevel / Garmin fēnix – technische Gesamtspezifikation

**Recherche- und Projektstand: 28.10.2026.** Bevel-Funktionsanalyse aus öffentlichen Quellen; Algorithmen und Code des Nachbaus sind unabhängig und experimentell.


---

# 01 · Funktionales Reverse Engineering: Bevel (öffentlich dokumentierte Funktionen)

**Stichtag 28.10.2026.** Wir vergleichen *beobachtbare Fähigkeiten* und Schnittstellen; keine Kenntnis über private Bevel-Datenbanken, Quellcode oder intern gelernte Modelle. Kennzeichen: **B = öffentlich belegt**, **A = Entwurfsannahme**, **O = offene technische Frage**.

## Produktkonzept

Bevel kombiniert Wearable-Daten, Training, Ernährung, Journal, Biomarker und individualisierte Empfehlungen. Hauptoberfläche: Home mit Tageszusammenfassung; Bereiche Fitness, Journal und Biology; Detailseiten Recovery, Sleep, Strain, Stress & Energy, Nutrition; zusätzlich KI-Assistent. Historische Release-Notizen und aktuelle FAQ zeigen 2026 die Garmin-Integration, Training Plans, erweiterten Strength Builder, Health Records und Biological Age. [S1][S2][S3].

## Vollständiger Funktionskatalog — priorisierte Nachbildung

| Domäne | Beobachtbare Bevel-Funktion | Datenvoraussetzung | Unser Plan | Evidenz |
|---|---|---|---|---|
| Dashboard | Drei Kernringe Strain, Recovery, Sleep; tägliche Einsichten, Timeline, Aktivitätsstatus | Scores, Uhrzeit, Status, Tagesereignisse | eigene Karten / Detailseiten, Verlauf | B [S1, S3] |
| Recovery | 1–100 %, einmal nach Schlaf; Schlaf, nächtliche HRV, RHR, Temperatur, Atmung, SpO₂ | 2+ Nächte, individuell kalibriert | Versioniertes eigenes Modell, missing -> null | B [S4, S5] |
| HRV | Standard RMSSD für unterstützte Apple Watch; Auswahl SDNN/RMSSD; Messfenster konfigurierbar | Roh-IBI oder native HRV, Zeitfenster | Garmin-nächtliche HRV **nicht** mit Apple-RR-Messung gleichsetzen | B [S5] |
| Baseline | 60-Tage-Trends / Vergleich Normal, Above, Below; 2–6 Wochen Kalibration | Nachtwerte 2–6 Wochen | 14 Nachtwerte Mindestzahl + 60-Tage-Fenster, eigene Skalen | B [S4, S6], A eigene Mindestzahl |
| Sleep | Sleep Score, Länge, Tief/REM, Unterbrechungen, Kontinuität, Schlafeffizienz | Garmin Schlafberichte | separates Standardisierungsschema, keine verlorenen Phasen | B [S4, S6] |
| Schlafbedarf | Sleep Need, Sleep Debt, Sleep Bank, Sleep Goal | Schlafhistorie, Ziel | eigenes rolling-debt-Konzept | B [S6] |
| Strain | Aktive Workouts + passive Aktivität, Zone / Dauer, nicht-lineare Summierung | HR über Tag, Aktivitäten, ggf. Kraftdaten | Gewichtete Zonenlast + eigener Log-Proxy | B [S7], A Formel |
| Target Strain | dynamisches Ziel aus Recovery und bisheriger Last | mehrere Tage Erholung/Belastung | nach Kalibration Zielbereich mit Sicherheitsregeln | B [S7, S8] |
| Stress | physiologischer Stress 0–100, nicht gleich mentaler Stress | HRV/HR und Aktivitätskontext | Garmin Stress separat; eigener Stress-Proxy nur nach Validierung | B [S6] |
| Energy Bank | Ladung über Schlaf/Ruhe, Abnahme bei Stress, Übertrag zwischen Tagen | Zeitreihe Schlaf & Stress | zunächst Garmin Body Battery separat, KEINE Umbenennung | B [S6] |
| Fitness | Aktivitäten, Tages/Wochenhistorie, PRs, Aktivitätsdetails, Splits/Intervalle, HF-Zonen | Aktivitäten + ggf. FIT | FIT-Aktivitätsimport und Charts | B [S3] |
| Cardio Load | akut 7 Tage vs chronisch 6 Wochen; Status-Klassen und Kalibration | HR-Workouts, HR-Baseline | ATL/CTL auf dokumentiertem eigenen Lastproxy | B [S9], A Proxy |
| Cardio Focus | Low Aerobic / High Aerobic / Anaerobic | Herzfrequenzzonen | Zeitverteilung und Zone Mapping | B [S3] |
| Strength | Trainingsroutinen, Satztypen, Supersets, Pausen, Progression, Live Sync | Benutzer-Workoutlog | Satz-DB, Workout-Editor, Garmin app optional | B [S10] |
| Muscular Load | 7 Tage / 6 Wochen, Übungsdaten, Gewichte, RPE | Übungsdaten mit Muskelmapping | eigenständige Volumen-/RPE-Analyse | B [S11] |
| Muscle Freshness | Kalibrierung nach 3 Trainingstagen je Muskel, Zustände erholt/ermüdet/leer | Muskelbelastung & Zeit | eigenes Erholungsmodell, ohne medizinische Versprechen | B [S11] |
| Ernährung | Barcode, Foto, Text, Datenbank, Makro/Mikro, eigene Speisen, Rezepte | separate Lebensmitteldatenbank + Nutzer-Logs | Food-Logs und API für offene Food-Datenbank | B [S12] |
| Nutrition Score | 1–100, Lebensmittelqualität & optional Glukose; nicht aus reinen Drittanbieter-Makros | vollständige Mahlzeitenkontexte | v1 nur Nährstoffsumme, Score später | B [S12] |
| Journal | Hydration, Sonnenlicht, Gewohnheiten, Ereignisse | manuelle Logs | Ereignismodell + Eingabeformular | B [S2] |
| Biology | HRV/RHR Baseline, VO₂max, Gewicht, BP, Blutwerte, biologisches Alter | Langzeitdaten/Med-Dokumente | nicht als validierte medizinische Altersberechnung ausgeben | B [S13] |
| Health Records | Labore und Dokumente, erkannte Biomarker, Verlauf | Upload mit hohem Schutzbedarf | Verschlüsselung + expliziter Opt-in + Revision | B [S2] |
| KI | Analysen, Coaching, Pläne, Mahlzeitenauswertung, wiederkehrende Check-ins | freigegebene Daten, regelbasierter Zugriff | optionales Modul mit Evidenzhinweisen & Guardrails | B [S14] |
| Share / Widgets | KPI-Karten und anpassbare Shares, Watch-Komplikationen | UI- und Wearable-Plattform | eigene Branding-Assets | B [S2] |

## Garmin-Sonderfall

Bevel beschreibt direkte Garmin-Connect-Integration, aber bei Garmin: 1 Monat historische Synchronisation, keine HRV tagsüber, Stress/Energy nur aus Herzfrequenz geschätzt, keine Garmin Connect+ Strength/Nutrition-Daten, und nicht alle Änderungen werden zurückgespielt. Live-Herzfrequenz aus Garmin ist in Bevel derzeit **nicht** unterstützt. [S15][S16]

Für uns: Garmin Personal API ist eigene **separate** Integration mit eigenen Nutzungsgrenzen. Das Bevel-Limit „1 Monat Historie“ ist nicht automatisch als technisches Garmin-Personal-API-Limit zu interpretieren.

## Nicht belegbar / nicht zu behaupten

- Exakte Scoregewichte und mathematische Funktionen für Recovery, Sleep, Strain, Energy Bank.
- Bevel-Datenbankschema, privates Backend, Authentifizierungs- und Sync-Implementierung.
- Exakte ML-Parameter für Biological Age und Food-Bildanalyse.
- Geschützte Bevel-Quellcodes, iOS-Binärinformationen, Design-Assets, proprietäre Übungsdatenbank.
- Gleichwertigkeit zwischen Garmin Body Battery, Bevel Energy Bank und experimentellem Energy-Proxy.

## UX-/Verhaltens-Testfragen für echte Black-Box-Prüfung

1. Ändert sich Recovery bei nachgetragenen Schlafdaten rückwirkend?
2. Wie behandelt Bevel Nächte ohne HRV oder mit RHR-Ausreißern?
3. Welche Tagesgrenze wird bei Schichtarbeit, Zeitreisen und Schlaf nach Mitternacht genutzt?
4. Wird Strain als Summe pro Aktivität oder als nichtlineare gemeinsame Funktion angezeigt?
5. Wie verhindert Bevel doppelte Workouts aus Garmin und Apple Health?
6. Wie unterscheiden sich importierte Krafttrainingsaktivitäten von direkt protokollierten Satzlogs?
7. Wie groß ist die Verzögerung zwischen Garmin Connect Sync und Bevel Anzeige?
8. Wie bewertet Bevel Sensordatenlücken? Diese Fragen müssen **gemessen**, nicht geraten werden.

Quellenzuordnung: `08-sources.md`.


---

# 02 · Architektur: Garmin ↔ Backend ↔ Web-App ↔ Uhr

## Logisches System

```mermaid
flowchart TB
  F[Fenix Wearable] -->|nativer Sync| GC[Garmin Connect]
  F -->|Connect IQ HTTPS optional| Q[Watch Upload Endpoint]
  GC -->|Personal API für EIGENE Daten| P[Raw Import Job]
  P --> R[Immutable raw records]
  Q --> R
  R --> N[Mapping/Normalization]
  N --> D[(PostgreSQL + Timeseries)]
  N --> V[Data quality validation]
  D --> E[Versioned score engine]
  E --> S[Daily score snapshots]
  S --> API[Authenticated API / Web-App]
  D --> API
  API --> UI[Web Dashboard]
  API --> W[Own Connect IQ watch UI]
```

## Garmin-Anbindung 1: Garmin Personal API (Hauptweg)

- Zugriff auf **eigene** Garmin Connect Daten, Pull, eigener Schlüssel aus Garmin Connect Web, OAuth2 Access Token mit ca. 24 h Lebensdauer, keine Refresh-Tokens. Schlüssel bleibt auf dem Server, nicht auf Uhr oder Browser. [S17]
- Offizieller Python-Client `garmin-connect-personal-api-python` liefert Wrapper für Schlaf, HRV, HF-Tageskurve, Steps, Stress, Body Battery, Aktivitätsdaten, Aktivitäten/FIT und Profileinstellungen. [S18]
- `garmin-import/fetch_personal.py` ruft diese Bibliothek für ein explizites Datumfenster auf und speichert **rohe Antworten** lokal. Nicht alle Felder werden von jeder fēnix und Firmware geliefert.
- Die sichere Mapping-Pipeline darf **niemals** „null“ als gemessene 0, Messfehler als gültige Daten oder SDNN als RMSSD behandeln. Die RAW-Struktur ist mit realen Daten zu prüfen, bevor ein Produktions-Mapping erstellt wird.
- Synchronisation ist erst möglich, wenn das Gerät → Garmin Connect erfolgreich abgeschlossen ist; kein Echtzeit-Kanal.
- Bei kommerzieller Mehrbenutzer-App offizielle *Business API* / Starter- oder Enterprise-Zugang, nicht Personal API. [S19]

## Garmin-Anbindung 2: Connect IQ (Zusatz)

- Auf der Uhr laufende Monkey-C-App (Watch-App, Glance oder bei Bedarf Data Field), die zulässige Werte über Communications.makeWebRequest als HTTPS-POST sendet.
- Foreground für manuelle Sync- und Trainingsfunktionen. Hintergrund nur mit Garmin-seitig unterstützten Intervallen/Limitierungen. Ein permanenter 1-Hz-/Live-Stream durch Background ist keine belastbare Annahme.
- Die **genaue** fēnix-7-/8-/9-Hardwarekennung muss mit SDK und echter Uhr geprüft werden. `watch/` enthält nur unkompilierten Quelltext.
- Authentifizierung: widerrufbarer Watch-Upload-Token pro Gerät. Upload erfordert serverseitige Validierung, Sequenz/ID für Duplikate und Offline-Queue für geplante Produktionsversion.
- Zum unmittelbaren Starten/Steuern von Kraftworkouts braucht es eine eigene UI auf Uhr und kompatible Connect-IQ-Funktionen. Garmin Connect Training API kann, bei passendem Business-Zugang, strukturierte Workouts und Kurse ans Garmin-Konto pushen, was nicht dasselbe wie eine direkte Echtzeitsteuerung ist. [S20]

## Kanonische Datenverarbeitung

1. Connector ruft Daten ab → RAW-Objekt, Source-ID, Import-Zeit, API-Endpoint, Datum, Versionskennung.
2. SHA-256/Deduplikation auf `(source, source_record_id, event_type)` bzw. hash + Zeitfenster; Source-Priorität pro Datenart.
3. Quellformat je Source+Schema-Version nach `canonical_measurement` transformieren, Einheiten UTC und lokale Zeitzone separat speichern.
4. QoS: `valid`, `missing`, `stale`, `estimated`, `source_conflict`, `not_supported`; Confidence und Provenance mitgeben.
5. Aktivitätsabgleich: Garmin activity ID / FIT UUID, Startzeit ±1–2 min + Dauer/Disziplin; nicht ohne Konfliktprotokoll automatisch zusammenwerfen.
6. Scores als deterministische Materialisierung je `(day, algorithm_version, data_revision)` schreiben. Korrigierte Rohdaten triggern Rebuild.
7. Frontend stellt sowohl Score, Baseline als auch Datenherkunft und Änderungsstatus dar.

## Zeitkonventionen

- Alle Ereignisse intern in UTC, Anzeige mit per-user-IANA-Timezone (z.B. `Europe/Berlin`), und Source-Zeitzone speichern.
- Nächte gehören zum **Aufwachdatum**. Bevel nutzt eine konfigurierbare Wake-Up-Time als Tagesgrenze. [S4]
- DST (Sommerzeitwechsel), Reise, Nickerchen, Schichtarbeit und Schlaf über Mitternacht müssen Testfälle sein.
- Latest-Snapshot ≠ longitudinaler Verlauf. Garmin Connect Tageswerte können nach Synclauf nachkorrigiert werden.
- Basiswerte nachts nur aus tatsächlich übermittelter Nachtmessung, nicht aus beliebigen Tagesherzfrequenzen ableiten.

## Offline / resilient

- Queue-Jobs wiederholen nur idempotente Anfragen mit exponentiellem Backoff; 429, 5xx, 401 unterschiedlich behandeln.
- Gesundheitsdaten nicht in Logger und Crashreports. Rohdaten verschlüsselt, klar festgelegte TTLs.
- API-Verfügbarkeit / veraltete Daten im UI markieren, nicht als aktuelle Messung ausgeben.
- Bei fehlender HRV **Recovery = null**, nicht null zu 50 ersetzen.
- Für private Einzelnutzung reicht ein lokaler Prozess zum Start; für öffentlich erreichbare Produktion sind DB, User-Auth, Cloud-/VPS-Sicherheit und DSGVO-Artefakte erforderlich.

## Architekturentscheidung

**V1 = Personal API + Web UI; V2 = Connect-IQ-Feature-App; V3 = Business API bei externer Benutzerschaft.** Nicht umgekehrt: Hauptdatenquelle ist Garmin Connect, Uhr-App ist Zusatzinstrument.


---

# 03 · Scoring und Modellgrenzen

## Quellenbefund: Bevel vs. unabhängige Rekonstruktion

**Bevel öffentlich belegt:**
- Recovery 1–100: Sleep Score, nächtliche HRV/RHR, evtl. Temperatur, Atemfrequenz, SpO₂. Baseline 60 Tage, in der Praxis 2–6 Wochen zur Stabilisierung. [S4][S5][S6]
- Sleep: Dauer relativ zum Schlafbedarf, Tief-/REM-Schlaf, Veränderungen des Schlafpulses, Effizienz und Unterbrechungen; nicht jede Komponente muss verfügbar sein. [S4]
- Strain: aktive + passive Last, Herzfrequenzzonen, Dauer, nichtlinear/logarithmisch; kann über 100 % gehen. [S7]
- Cardio Load: 7-Tage-ATL versus 6-Wochen-CTL; Belastungsmonitor mit Statuskategorien. [S9]
- Energy Bank: über Tage fortgeschriebene Energie, Schlaf/Ruhe lädt auf, Stress senkt. [S6]

**Nicht bekannt:** exakte Formeln, Gewichte, Smoothing, Sonderfallbehandlung, Kalibrationsfunktionen, Modellparameter. Keine wissenschaftliche Gleichwertigkeit behaupten.

## V0.1: exakte **eigene**, überprüfbare Codeformeln

Code: `app/src/scoring.mjs`. Einheit & Version auf jedem Score speichern (`pulseforge-experimental-0.1`). Jeder relevante Input bleibt belegbar.

### Baseline

- Aus den 60 vergangenen Kalendertagen nur **gültige** Werte verwenden.
- Mindestens 14 gültige Vornächte für jeweils HRV und RHR, sonst Recovery **nicht berechnen**.
- Robuster Median `m` und MAD `median(|x-m|)`, Skala `s=max(1.4826*MAD, 0.05*|m|, 0.0001)`.
- Aktuelle Nacht NICHT in den Referenzbereich einrechnen (vermeidet Leckage).

### Sleep Score v0.1

- Benötigt tatsächliche Schlafdauer `T` in Minuten sowie konfigurierten Schlafbedarf `N` (v0.1: Default 480 min).
- `duration = clamp(T/N,0,1)`.
- Falls `inBedMinutes` plausibel vorliegt, `efficiency = clamp(T/inBed,0,1)`.
- `sleep = round(100 * (0.75*duration + 0.25*efficiency))`.
- Fehlt Effizienz, wird nur Dauer verwendet. **Keine Bevel-Spezifikation**, Tief-/REM-Schlaf noch nicht enthalten.
- Eine Nacht über 8 h wird auf 100 % gedeckelt; unzureichend für differenzierte Schlafqualität. Höhere Auflösung erst bei ausreichender validierter Datenbasis.

### Recovery Score v0.1

- Nur mit `sleep`, `HRV_RMSSD`, `RHR` und beiden Baselines.
- `zH = clamp((HRV - medianHRV)/scaleHRV, -2.5, +2.5)`
- `zR = clamp((medianRHR - RHR)/scaleRHR, -2.5, +2.5)`
- `score = round(clamp(60 + 0.38*(10*zH) + 0.32*(10*zR) + 0.30*((sleepScore - 75)*0.6), 0,100))`
- Gewichte **von uns gewählt**, nicht statistisch validiert; bei echter Validierung und Datenqualität ändern.
- Temperatur/SpO₂/Atmung fehlen noch bewusst; Datenqualität sichtbar machen.

### Aktivitäts-Lastproxy und Strain

- Fünf HR-Zonen, Eingabe Minuten pro Zone `[z1,z2,z3,z4,z5]`, alle aus derselben Workouts-Quelle.
- `L = 1*z1 + 2*z2 + 3*z3 + 5*z4 + 8*z5` (gewichtete Zonenminuten).
- Mehrere Workouts eines Tages: `L_total = Summe L_i`.
- Nur *aktiver* Proxy: `Strain = round( clamp(100 * ln(1 + L_total) / ln(1 + 500),0,130) )`.
- Konstante `500` und Gewichte sind **explizit experimentell**. Kein Strain ohne Zone-Minuten; Schritte werden derzeit nicht doppelt zu Workouts addiert.
- **Passive Strain, Muskelbelastung und präzise Target Strain sind noch nicht implementiert**. Anzeige enthält diese Einschränkung.

### Cardio ATL/CTL

- `ATL = Mittelwert(L_t für letzte 7 Kalendertage)`; `CTL = Mittelwert(L_t für letzte 42 Kalendertage)`.
- Null Trainingsbelastung an trainingsfreien Tagen nur, wenn Tag als mit vollständiger Workouterfassung markiert ist.
- Der Prototyp verlangt 42 vorhandene Tageseinträge und für jeden der 42 Tage ein Workout-Array (auch leer); sonst `calibrating`.
- `ratio = ATL/CTL` bei CTL>0. Zustände/Schwellen im Produkt erst nach longitudinaler Kalibrierung.
- Dies ist **kein** validiertes TRIMP oder Bevels unveröffentlichte Cardio-Load-Rechnung.

### Body Battery versus Energy Bank

Garmin Body Battery ist ein eigenständiger herstellerseitig berechneter Score. Bevel Energy Bank ist ein anderes Modell. Im Prototyp heißt das Feld explizit `garminBodyBattery` und wird **nicht** in Bevels Energy Bank umbenannt. Ein eigener Energy-Proxy käme erst nach definiertem State-Space-Modell, Sensorgüte- und Zeitsynchronisationsprüfung.

### Krafttraining v1/v2 Vorschlag

Für jede Übung/Satz `volume = reps × weightKg`; `muscleContribution = volume × muscleActivationWeight`, pro Muskel zuletzt 7 vs 42 Trainingstage. *Muscle Freshness* könnte durch zeitabhängige Lastreduktion via exponentiellem Abbau `F(t)=Σ load_i*exp(-(t-t_i)/τ_muscle)` geschätzt werden. **τ, Muskelgewichte und Interpretation sind frei zu kalibrierende Entwurfswerte, nicht Bevels Formel**. Ohne Satzlogs keine zuverlässige Muskelbelastung aus importierten Garmin-Kraft-Workouts ableiten.

## Validierung vor echtem Einsatz

- Diagnostische Sensitivität/klinische Güte nicht behaupten. Keine Grundlage für individuelle medizinische oder Trainingsfreigabe.
- Golden Fixtures mit erwarteten Werten für vollständige, fehlende, veraltete und unplausible Nächte.
- Benchmark zu ausgewählten Bevel-Tagen ist möglich, **nur mit rechtmäßig zugänglichen eigenen angezeigten Werten** und ohne Kopieren proprietärer Binärlogik; Parameter unverwechselbar/versioniert dokumentieren.
- Messgrößen: MAE und R² Score-Vergleich, Spearman-Trendkorrelation, Anteil `null`, Time-Lag, Score Drift bei Wiederimport. Gleiche Anzeigezahlen sind kein Qualitätsbeweis.


---

# 04 · Kanonisches Datenmodell, APIs & Produktionsschema

## Ziel

Eine **versionsstabile Trennschicht** zwischen Garmin-Spezialfeldern und unserer eigenen App. Rohdaten nicht nur „umbenennen“: Messzeit, Einheit, Source, Aggregationsfenster, Provenance und Revision benötigen eine klare Semantik.

## Minimaler kanonischer Tagesdatensatz (im Demonstrator bereits lauffähig)

```json
{
  "date": "2026-10-28",
  "sources": ["garmin-personal/confirmed-map"],
  "sleep": {
    "asleepMinutes": 455,
    "inBedMinutes": 490,
    "deepMinutes": 91,
    "remMinutes": 105,
    "awakeMinutes": 35
  },
  "night": {"hrvRmssdMs": 54, "restingHeartRateBpm": 51},
  "garmin": {"steps": 8000, "bodyBattery": 72, "stress": 30},
  "workouts": [
    {"type":"run", "zoneMinutes":[8,12,23,7,1]}
  ]
}
```

Alle Zahlen in diesem Beispiel sind **fiktiv**. `date` = Aufwachdatum in lokalem Tageskontext, nicht automatischer UTC-Kalendertag. Die Berechnungs-Engine kann nur `hrvRmssdMs` sinnvoll verwenden; SDNN darf nicht in dieses Feld geschrieben werden. `workouts: []` bedeutet **verifizierte leere Aktivitätsliste** für den Tag; fehlendes `workouts` bedeutet `unknown` und darf nicht automatisch als trainingsfrei gewertet werden.

## Tatsächlich implementierte API-Endpunkte (lokaler Prototyp)

| Methode | Pfad | Auth | Antwort / Zweck |
|---|---|---|---|
| GET | `/healthz` | keine | Healthcheck ohne Gesundheitsdaten |
| POST | `/api/v1/days` | `X-Admin-Token` | validierte normalisierte Tagesdaten speichern |
| GET | `/api/v1/days` | `X-Read-Token` | alle vorhandenen Tage |
| GET | `/api/v1/summary?date=YYYY-MM-DD` | `X-Read-Token` | Tagesdatensatz + berechnete Scores |
| POST | `/api/v1/watch` | `X-Device-Token` | Connect-IQ-Snapshot speichern |
| POST | `/api/garmin/ingest` | `X-Device-Token` | kompatibler Alias für vorherigen Uhren-Code |
| GET | `/api/v1/watch/latest` | `X-Read-Token` | letzter Snapshot |

Browser-Dashboard `GET /`, CSS und JS ausschließlich lokal. Token wird nur im Speicher des geöffneten Browsers gehalten. Demo-Werte erscheinen ohne Token. **Kein produktives Sessionsystem**.

## Garmin-Rohdatenexport & verifiziertes Mapping

- `garmin-import/fetch_personal.py`: offizielle Garmin Bibliothek für Rohdaten. Speicher `data/raw/garmin/YYYY-MM-DD/{sleep,hrv,heart_rate}.json` und Fenster-Summaries beim ersten Datum.
- `inspect_shapes.py`: nur Feldpfade ausgeben, keine Werte (trotzdem sensible Metadaten möglich).
- `mapping.example.json`: **unbestätigte** *Beispielpfade*; absichtlich `confirmed:false`.
- `normalize_confirmed.mjs`: verweigert die Ausgabe, bis die Feldpfade/Einheiten nach echten Antworten bestätigt sind; dann konvertiert es angegebene Faktoren und validiert Datums-/Einheitenbereiche.
- Importer schreibt die API-Daten **nicht** direkt in die App, um falsche HRV- oder Schlaf-Einheiten zu verhindern.
- Nur die bestätigte JSON-Datei wird mit `POST /api/v1/days` importiert.

Beispiel für den manuellen Verifikationsschritt:

```bash
cd garmin-import
python inspect_shapes.py ../data/raw/garmin/2026-10-28/{sleep,hrv,heart_rate}.json
# mapping.example.json KOPIEREN und nach Prüfung Feldpfade + Einheiten setzen,
# confirmed auf true setzen; nicht unkontrolliert auf alles mappen.
node normalize_confirmed.mjs --date 2026-10-28 --mapping mapping.confirmed.json \
  --out /tmp/confirmed-2026-10-28.json
curl -H "X-Admin-Token: $ADMIN_TOKEN" -H 'Content-Type: application/json' \
  -X POST --data-binary @/tmp/confirmed-2026-10-28.json \
  http://127.0.0.1:3477/api/v1/days
```

## Zieldatenmodell PostgreSQL (separat `database/schema.sql`)

- `users`, `data_sources`, `devices`: getrennte Konten und Geräte, Key-Referenzen, Widerruf.
- `raw_ingest_events`: revisionssichere Raw-Texte, Payload-Hash, ID-String, Source, Error/Quarantine.
- `observations`: UTC-Zeit, End-Zeit, Feldname, Wert, Einheit, Fenster, Qualität, Quelle, Versionsstand.
- `sleep_sessions`, `sleep_stages`: Schlaf über Mitternacht; Nächte auf Aufwachdatum beziehen.
- `activities`, `activity_samples`, `exercise_sets`: Garmin-ID, FIT-Referenz, Herzfrequenzzonen, Zeitreihen, Übungsdaten.
- `nutrition_logs`, `journal_entries`: optional, separate nutzerseitige Erfassung.
- `score_snapshots`: Algorithmusversion, Input-Revision, Confidence, Nullgründe, strukturierte Komponenten.
- `audit_events`, `processing_jobs`, `source_preferences`: Herkunft, Duplikate, API-Verzögerungen und Datenexport.

## API-Design für endgültige Web-App

- OAuth/sessionbasierte User-Auth statt READ_TOKEN im Browser; `user_id` aus Session, nicht aus untrusted Query.
- Paginated Data APIs (`cursor`, `limit`), `ETag`, serverseitiger Cache, Ratelimits und getrennte Berechtigungen für Aktivitäten/Labore/Ernährung.
- Historische Revisionsabfrage: „Wieso wurde mein Score vom Dienstag nachträglich verändert?“
- `DELETE /account/export` bzw. klare Export-/Lösch-Workflows nach Authentifizierung; keine öffentlich zugänglichen Raw Dumps.
- Jede Scoreantwort enthält `algorithm_version`, `provenance`, `input_coverage`, `computed_at`, `warnings`.

## Prototypbeschränkungen

- JSON-Datei wird als Ganzes eingelesen/geschrieben, kein gleichzeitiger produktiver Mehrbenutzerbetrieb, keine Transaktionsgarantie, keine Encryption-at-rest, keine Retention-Automation.
- Kein fertiger FIT-Parser, keine Trainingsplan-Push-API, kein Vollimport aus Garmin ohne Mapping-Freigabe.
- Nur für localhost-Test geeignet, **nicht** öffentlich ins Internet stellen ohne zusätzliche Absicherung.


---

# 05 · UI-/UX-Blueprint und Watch-Workflows

## Informationsarchitektur (eigenständiges Design, keine Bild-/Asset-Kopie)

### Hauptnavigation

1. **Overview:** Tagesdatum, 3 kompakte Scores, Datenfrische, Energie/Stress, letzte Aktivitäten, Timeline und schnelle Eingaben.
2. **Recovery:** 1–100 mit Konfidenz, HRV/RHR, Baseline, Trends 7/30/60 Tage, Anomalien. Nullgründe sichtbar.
3. **Sleep:** Primärschlaf, Schlafstadien als Timeline, Dauer, Effizienz, Schlafbedarf, Ziel, Schlafdefizit, Tages-/Wochenverlauf.
4. **Strain:** aktiv/passiv/muskulär (getrennte Herkunft), Herzfrequenzzonen, Tagesziel und zurückliegende Trainingslast.
5. **Fitness:** Trainingskalender, Art/Dauer/Distanz, Cardio Load/Focus, Splits, Personal Records, VO₂max falls vorhanden, Laufanalytik nur wenn Quellgerät verfügbar.
6. **Strength:** Übungen, Workouts und Routinen, Satztypen (normal/Warmlauf/Drop/Failure), RIR/RPE, Gewichte, Volumen, 1RM (klar als Schätzwert), Muskelkarte, Trends und PRs.
7. **Nutrition:** Scanner, Rezept/Produkt, Portion, Makro/Mikro, tägliche Energieaufnahme, Datenqualität der Food-Datenbank.
8. **Journal / Timeline:** Gewohnheiten, Symptome, subjektive Erholung, Workouts, Mahlzeiten, Schlaf, Zeitachsen-Korrekturen.
9. **Biology:** HRV- und RHR-Longitudinalwerte, Blutdruck, Gewicht, Biomarkerdateien, eigene biologische-Alter-Projektion nur nach hinreichender Modellvalidierung.
10. **AI / Settings:** Insights, Transparenz der Datenfreigabe, Modelleinstellungen, Geräte, Kalibrationsstatus, Export/Löschen, Datenschutz.

### Klickpfade

`Home → Recovery Ring → Recovery Details → HRV Chart → Datenherkunft → Original-Garmin-Quelle`.

`Home → Strain → Workout → HR-Verlauf / Zonen → FIT-Aktivität → Garmin Original-ID`.

`Fitness → Strength → Trainingsplan → Einheit → Übung → Satz → Timer/Logging → Nachbearbeitung`.

`Settings → Data Sources → Garmin → API-Verbindung prüfen → letzte Synchronisierung → Datenfehler`.

### Zustände (jede Karte)

- `loading`, `no_data`, `insufficient_baseline`, `stale`, `partial`, `ready`, `inconsistent`, `import_error`.
- Score `null` = „nicht berechnet“, **niemals** „0 % Recovery“. 0 ist ein extrem niedriger, aber messbarer Score; beides getrennt.
- Sensitivitätswarnungen: Erholung ist Wellness-/Trainingsindikator, keine Diagnose; keine medizinischen Entscheidungen daraus ableiten.
- Bei Garmin Body Battery und eigenem Energy-Proxy distinct Labels/Legende verwenden.

## Layout & Visualisierung

- Responsive 1–3 Spalten, Desktop-Navigation, Bottom-Navigation für mobile PWA.
- Farbsprache: Orange = Belastung, Grün = Erholung, Indigo = Schlaf; die Farbe allein kodiert niemals eine Entscheidung.
- Score-Ring immer mit numerischem Wert, Einheit, Erfassungszeit, Qualitäts-/Konfidenzhinweis.
- Baseline-Charts inkl. Median, individuellem Referenzkorridor, Datenlücken, ausgewähltem Zeitfenster.
- Aktivitäten: Markierung von Datenquellen, Importrevision, Doubletten und geplanten vs. absolvierten Einheiten.
- Zeiten in der IANA-Zeitzone des Nutzers, bei Zeitumstellung korrekt.
- WCAG-kontrastreiche Schriften und alle Interaktionen tastaturbedienbar; optionale kompakte Uhrenansicht.

## Garmin fēnix Watch-App, Versionen

**MVP-Uhr-App:**
- Status der letzten erfolgreichen Synchronisation + timestamp
- Manueller „Jetzt senden“-Button, bewusst asynchron
- Akkustand und verfügbare Werte als Momentaufnahme
- Sichtbarer Offline-/Fehlerstatus; keine verschwiegene Datenlücke

**Training Watch-App (separater Schritt):**
- Routine wählen → Übung anzeigen → Satz/Wdh./Gewicht eintippen → Pausentimer → nächster Satz
- Watch-Offlinequeue mit eindeutiger Ereignis-ID, späterer idempotenter Sync
- Optional Live-HR nur nach konkreter SDK-Prüfung; nicht alle Garmin Vitaldaten sind freigegeben
- Garmin-eigene Training-Records und eigene Sätze sauber korrelieren

**Optionale Glance:** Recovery, heutige Belastung, letzte Synczeit. Nicht versprechen, dass jede fēnix diese identisch unterstützt.

## Tatsächlich in `app/public/` implementiert

- Eigenständiges, responsives HTML/CSS/JS-Dashboard.
- Tabs Overview, Recovery, Sleep, Fitness, Strength (Spezifikation), Sources.
- Authentifizierter Abruf der persönlichen Tagesdaten, Lesetoken nur in flüchtigem Speicher.
- Explizite synthetische Demowerte und beschriftete Placeholder-Grafik.
- Karten für Schlaf, Erholung, aktiven Strain, Body Battery, Stress, Workouts, Datenherkunft.
- Noch keine echten Zeitreihenplots, kein vollständiger Trainings-/Essens-Editor, kein markenidentisches Design.


---

# 06 · Datenschutz, Sicherheit und klinische/Wellness-Abgrenzung

## Bedrohungsmodell

Betroffene Objekte: persönliche Garmin-Keys, OAuth2-Token, GPS-/Standortverläufe, Trainings-/Gesundheitsdaten, Laborberichte, Ernährung und sensible Journalnotizen. Bedrohungen: fremde Zugriffe, Token-Exfiltration von der Uhr, versehentliche Publikation, fehlerhafte Mandantentrennung, Sync-Duplikate, falsche Scoreinterpretation, unkontrollierte Cloud-Log-Ausgaben.

## Unabdingbare Schutzmaßnahmen vor öffentlichem Produktbetrieb

1. **Datenminimierung:** nur erlaubte Datentypen und explizite Einwilligung; nicht jede FIT-Koordinate erfassen, wenn für Scores nicht nötig.
2. **Zugangsdaten:** Garmin Personal API Key ausschließlich serverseitig, optional Vault/KMS; Rotation, Widerruf, sichere Files `0600`; nie im Git, nie Browser, nie Uhr.
3. **Uhren-Upload:** restriktiver, widerrufbarer Schreib-Token je Gerät mit Token-Rotation, Ratelimits und Missbrauchserkennung; Watch-Token als potenziell extrahierbar behandeln.
4. **Transport:** immer TLS; Backend hinter Reverse Proxy; mTLS sofern sinnvoll; keine „self-signed cert disabled“ Umgehungen.
5. **Speicherung:** PostgreSQL mit Backups/Encryption-at-rest, konkrete Löschfristen, Zugriffsprotokoll, Transaktions- und Duplikatsicherheit.
6. **Mandanten:** User-Identity ausschließlich aus sicherer Session, Row-Level Security oder strikt getrennte Queries; IDOR-Tests und Ownership-Checks.
7. **DSGVO:** Gesundheitsdaten können besonders geschützte personenbezogene Daten nach Art. 9 DSGVO sein. Rechtsgrundlage, Einwilligung/ggf. Ausnahmen, Verarbeitungsverzeichnis, Auftragsverarbeitung, Lösch-/Auskunftsrechte und ggf. DSFA klären; hierzu qualifizierte Rechtsprüfung einholen.
8. **KI-Modul:** keine unkontrollierte Übermittlung von Gesundheitsakten an Dritte; Opt-in, Datenminimierung, Sichtbarkeit externer Anbieter, Audit und keine Diagnosen aus Wellness-Scores.
9. **Klinische Abgrenzung:** Trainings- und Wellness-Feedback ist nicht automatisch Medizinprodukt. Zweckbestimmung, klinische Behauptungen, Nutzergruppe und EU-MDR-Risiken prüfen; ohne Validierung keine klinischen Empfehlungen oder „gesund/krank“-Entscheidungen ableiten.
10. **Offenheit:** Modellversion und Grenzen, Messlücken, Tageszeitzone, Herkunft der Werte, Unsicherheiten immer nachvollziehbar anzeigen.

## Sicherheitsstatus dieses Pakets

- Backend standardmäßig nur an `127.0.0.1` gebunden, getrennte Upload/Admin/Read-Token, konstante Zeit bei Tokenvergleich, maximale Requestgröße und einfache Feldvalidierung.
- Statische Website mit einer einschränkenden CSP, kein Tracking, keine Cloud-SDKs, kein eingebautes fremdes Bevel-Material.
- **Nicht production-ready:** eine lokale JSON-Datei, keine externe Benutzerverwaltung, Token im Browser für lokalen Zugriff, keine Datenverschlüsselung auf Anwendungsebene, keine Access-Logs/Job-Queue, kein Penetrationstest.
- Für die Uhr muss das Geräteverhalten und Token-/Speicherbudget separat getestet werden.


---

# 07 · Umsetzung, Abnahmekriterien & Bevel-Black-Box-Validierung

## Reihenfolge und überprüfbare Deliverables

### Phase A · Datenzugang / Schema (höchste Priorität)

1. Exakte fēnix Hardwarekennung, Firmware und Sensor-/Garmin-Connect-Einstellungen dokumentieren.
2. Eigener Garmin Personal API Key auf Garmin Connect Web; Python Client starten; lokale Rohdaten einer Nacht und eines Workouts ablegen.
3. JSON-Feldpfade und Einheiten an realen Rohantworten bestätigen; Mappings per Fixture testen.
4. Datenmodell mit UTC-Zeit, Zeitzone, Nachtzuordnung und Source-Priorität; Postgres migrieren.

**Definition of Done:** Ein echter Schlafreport + HRV + RHR + Aktivität ergibt einen validierten kanonischen Tagesdatensatz, jeder Wert ist auf den Raw-API-Aufruf zurückführbar, keinerlei Einheitenverwechslung.

### Phase B · Score Engine und Dashboard

1. Nacht-Baseline mit 14–60 gültigen Tagen, zeitlicher Datenabdeckung und Ausreißerregeln.
2. Score-Versionierung und Recompute nach Datenrevision.
3. Trendchart und tägliche Score-Komponenten mit pro-Source-Qualität.
4. Alternative Score-Metriken / Kalibration anhand dokumentierter Längsschnittdaten.

**DoD:** Score-Unit-Tests inklusive DST, Reisen, Missing HRV, Neuimport, Duplikate, Gerätetausch. Keine Zahlen bei Missing-Baseline.

### Phase C · Watch-App, Workout-Details und Strength

1. Monkey-C-Gerätebuild pro tatsächlichem Zielgerät, Garmin-Simulator und Hardware-Test; Speicherlimit beobachten.
2. Manueller HTTPS-Upload, Retries/Offlinequeue und Auth; Server-Ingest bewusst idempotent.
3. FIT Import + Workout Merge, keine doppelten Workouts aus API/Watch/Apple Health.
4. Eigener Krafttrainingseditor mit Workout-Plänen, Satztypen, Live-Timer, PRs, Muskelkarten.

**DoD:** eine Woche zuverlässiger Nachsync unter Bluetooth-Ausfällen; nachvollziehbares Fehler-/Retryprotokoll; ein Krafttraining end-to-end.

### Phase D · Vollständige Bevel-ähnliche Funktionalität

Nutrition Foodlog + Produktdatenbank und Prüfbarkeit; Journal; Health Records; eigene Biomarker/biologisches Alter nur nach Modellvalidierung; optional KI-Coaching mit Opt-in; Business Garmin APIs für fremde Nutzer; Barrierefreiheit/Datenschutz/Kommerzialität.

## Clean-Room-Black-Box-Validierung

- Vergleich ausschließlich mit **selbst autorisiert beobachteten** Bevel-Anzeigen und Garmin-Daten, nicht App-Binärdateien, versteckte Token oder private Infrastruktur bearbeiten.
- Paare mit gleichem Aufwachdatum, gleichem Device und gleichem Quellsetting erfassen.
- Pro Tag notieren: Bevel Sleep/Recovery/Strain/Target Strain/Energy, Garmin HRV/RHR/Schlaf/Workout, Uhr-Synczeit und Quellenstatus.
- Kontrollierte Szenarien: anstrengender Trainingstag, Ruhetag, wechselnder HRV, fehlender Schlaf, Schlaf nach Mitternacht, Fitnessgerätwechsel, korrigiertes Training, 2 gleiche Workouts aus verschiedenen Quellen.
- Korrelationen und Fehler getrennt pro Metrik/Untergruppe statt globales „99% genau“.
- Kein Modellgewichts-Tuning auf dieselben Tage, auf denen Genauigkeit demonstriert wird (separates Holdoutfenster).
- Bevel ist kein Goldstandard für physiologische Wahrheit; Reproduzierbarkeit und Plausibilität der eigenen Metrik wichtiger als numerische Übereinstimmung.

## Abnahmetests

| Fall | Erwartetes Verhalten |
|---|---|
| 1 Nacht ohne HRV | Recovery = `null`, fehlender Grund explizit |
| 13 valide Baseline-Nächte | Recovery = `calibrating` |
| 14+ HRV/RHR-Nächte | Recovery berechenbar, plausibler Bereich 0–100 |
| Schlaf falsch in Sekunden interpretiert | Importvalidierung weist unplausible Minuten zurück |
| Derselbe Connect-IQ Upload zweimal | Nur eine Momentaufnahme / eindeutiger Event |
| Garmin Connect Sync verzögert | Letzte Aktualisierung/stale, keine Echtzeitbehauptung |
| Body Battery = 65 | Anzeige „Garmin Body Battery 65“, nicht „Bevel Energy Bank“ |
| 42 vollständige Trainingstage | ATL/CTL und eigene Last berechenbar |
| 14 Tage fehlen beim Training | Cardio-Kalibrierung bleibt offen, keine fiktiven 0-Tage |
| Fremder Nutzer fordert Datensatz an | 401/403, keine privaten Daten |

**Aktueller Teststand:** Node-Code ohne externe Abhängigkeiten; Unit-Tests; noch kein Garmin-Liveaufruf, Watch-Kompilierung oder End-to-End-Echtzeittest.


---

# 08 · Quellen, alle existierende offizielle Dokumentationen (Abruf 28.10.2026)

Belegkürzel aus den anderen Kapiteln. Bevel-Dokumentation ist **Produktbeschreibung**, keine Veröffentlichung der geheimen Formeln. Garmin-Dokumentation ist Grundlage für unterstützte Schnittstellen, aber ein konkreter Geräte-/Konto-Test bleibt nötig.

- **[S1]** Bevel Produktseite: https://www.bevel.health/de
- **[S2]** Bevel Version/Feature History, zuletzt Stand Oktober 2026: https://help.bevel.health/en/articles/11194113
- **[S3]** Bevel Key Terms / Features: https://help.bevel.health/en/articles/11251073
- **[S4]** Bevel Common Questions (Recovery, Sleep, 60 Tage, 2–6 Wochen): https://help.bevel.health/en/articles/11257601
- **[S5]** Bevel Recovery / HRV / RHR: https://help.bevel.health/en/articles/11258177 und https://help.bevel.health/en/articles/10431233
- **[S6]** Bevel Key Bevel Terms (Stress, Energy, Sleep, Cardio): https://help.bevel.health/en/articles/11251073
- **[S7]** Bevel Strain Common Questions: https://help.bevel.health/en/articles/11257857
- **[S8]** Bevel Strain Performance: https://help.bevel.health/en/articles/14124737
- **[S9]** Bevel Training Load (ATL 7 / CTL 6 Wochen): https://help.bevel.health/en/articles/14206721
- **[S10]** Bevel Strength Builder Fragen: https://help.bevel.health/en/articles/11258753
- **[S11]** Bevel Muskel Load/Freshness: https://help.bevel.health/en/articles/14206849
- **[S12]** Bevel Ernährung: https://help.bevel.health/en/articles/11247745 und https://help.bevel.health/en/articles/11259073
- **[S13]** Bevel Biological Age: https://help.bevel.health/en/articles/11586369
- **[S14]** Bevel Intelligence: https://help.bevel.health/en/articles/11586817
- **[S15]** Bevel Garmin-Integrationsgrenzen: https://help.bevel.health/en/articles/10400449 und https://help.bevel.health/en/articles/11680065
- **[S16]** Bevel Data Sources FAQ zu Garmin-Live-HR: https://help.bevel.health/en/articles/13004417
- **[S17]** Garmin Personal API FAQ / Authentication: https://developer.garmin.com/gc-developer-program/personal/personal-faq
- **[S18]** Garmin offizieller Personal API Python Client / tatsächliche API-Endpunkte: https://github.com/garmin/connect-personal-api-python
- **[S19]** Garmin Connect Developer Program: https://developer.garmin.com/gc-developer-program/overview/
- **[S20]** Garmin Connect Developer Program Training-API- und Connect-IQ-Strategie: https://developer.garmin.com/gc-developer-program/
- Garmin Connect IQ Kommunikations-API: https://developer.garmin.com/connect-iq/api-docs/Toybox/Communications.html
- Garmin Personal API Endpoint Swagger: https://developer.garmin.com/gc-developer-program/personal/swagger-docs
- Garmin Support Personal API: https://support.garmin.com/de-DE/?faq=HfTwLfw1Gn2A7WS1GdAMH8

**Evidenzstatus:** Diese Links belegen die beschriebenen Produktfunktionen und API-Fähigkeiten; sie belegen **nicht** den eigenen Scorealgorithmus. Eigene Formeln sind im Code transparent und als experimentell ausgewiesen.
