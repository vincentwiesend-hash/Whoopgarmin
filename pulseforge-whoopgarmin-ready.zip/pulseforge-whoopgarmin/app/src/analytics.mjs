/**
 * Independent local-first analytics inspired by common fitness dashboards.
 * NOOP/WHOOP source code is NOT copied. No proprietary Bevel/Garmin algorithms.
 * All computations are descriptive, not diagnostic; null means unavailable.
 */
import { scoreDay, trainingLoad, finiteNumber } from './scoring.mjs';

export const ANALYTICS_VERSION = 'pulseforge-descriptive-0.2';
export const METRICS = Object.freeze({
  hrv: { label: 'Nächtliche HRV', unit: 'ms', higher: 'neutral' },
  rhr: { label: 'Ruhepuls', unit: 'bpm', higher: 'neutral' },
  sleepMinutes: { label: 'Schlafdauer', unit: 'min', higher: 'neutral' },
  sleepScore: { label: 'Schlafscore (experimentell)', unit: '/100', higher: 'neutral' },
  recovery: { label: 'Recovery (experimentell)', unit: '/100', higher: 'neutral' },
  strain: { label: 'Trainingsbelastung (Proxy)', unit: '/100+', higher: 'neutral' },
  trainingLoad: { label: 'HF-Zonenlast (Proxy)', unit: 'Punkte', higher: 'neutral' },
  steps: { label: 'Schritte', unit: '', higher: 'neutral' },
  stress: { label: 'Garmin Stress', unit: '/100', higher: 'neutral' },
  bodyBattery: { label: 'Garmin Body Battery', unit: '/100', higher: 'neutral' }
});
const permitted = Object.keys(METRICS);
const norm = n => finiteNumber(n) ? n : null;
const round = (n, digits=2) => n == null ? null : Number(n.toFixed(digits));
const dateUTC = date => Date.parse(`${date}T12:00:00Z`);
const asDate = timestamp => new Date(timestamp).toISOString().slice(0,10);

export function pearson(pairs, minPairs=7) {
  const clean = pairs.filter(p => Array.isArray(p) && p.length === 2 && p.every(finiteNumber));
  if (clean.length < minPairs) return {r:null,n:clean.length,state:'insufficient_pairs'};
  const n=clean.length, a=clean.map(p=>p[0]), b=clean.map(p=>p[1]);
  const meanA=a.reduce((s,x)=>s+x,0)/n, meanB=b.reduce((s,x)=>s+x,0)/n;
  let cross=0, va=0, vb=0;
  for (let i=0;i<n;i++) {const dx=a[i]-meanA,dy=b[i]-meanB;cross+=dx*dy;va+=dx*dx;vb+=dy*dy;}
  if(va<=0 || vb<=0) return {r:null,n,state:'no_variation'};
  return {r:round(Math.max(-1,Math.min(1,cross/Math.sqrt(va*vb)))),n,state:'descriptive_only'};
}

function extract(d,s) {
  return {
    hrv:norm(d.night?.hrvRmssdMs), rhr:norm(d.night?.restingHeartRateBpm),
    sleepMinutes:norm(d.sleep?.asleepMinutes), sleepScore:norm(s.sleep),
    recovery:norm(s.recovery?.score), strain:norm(s.strain?.score),
    trainingLoad:norm(trainingLoad(d)), steps:norm(d.garmin?.steps),
    stress:norm(d.garmin?.stress), bodyBattery:norm(d.garmin?.bodyBattery)
  };
}
function meanKnown(list) { const v=list.filter(finiteNumber);return v.length?{mean:v.reduce((a,b)=>a+b,0)/v.length,n:v.length}:{mean:null,n:0}; }
export function describeChanges(series) {
  // Two distinct, non-overlapping seven-calendar-day periods; no imputation.
  const out=[];
  for(const metric of ['hrv','rhr','sleepMinutes','strain']) {
    const recent=meanKnown(series.slice(-7).map(x=>x.values[metric]));
    const previous=meanKnown(series.slice(-14,-7).map(x=>x.values[metric]));
    if(recent.n<5 || previous.n<5) continue;
    const diff=round(recent.mean-previous.mean,1);
    const sign=diff>0?'+':'';
    out.push({metric,kind:'period_difference',difference:diff,priorMean:round(previous.mean,1),currentMean:round(recent.mean,1),nPrevious:previous.n,nCurrent:recent.n,
      statement:`${METRICS[metric].label}: ${sign}${diff} ${METRICS[metric].unit} im 7-Tage-Mittel gegenüber der Vorwoche (je ${previous.n}/${recent.n} Messwerte).`});
  }
  return out;
}
export function buildAnalytics(days, options={}) {
  const windowDays=[7,14,28,42,90].includes(Number(options.windowDays)) ? Number(options.windowDays) : 28;
  const first = permitted.includes(options.first) ? options.first : 'hrv';
  const second = permitted.includes(options.second) ? options.second : 'rhr';
  const dated = [...days].filter(d=>typeof d?.date==='string' && /^\d{4}-\d{2}-\d{2}$/.test(d.date) && Number.isFinite(dateUTC(d.date))).sort((a,b)=>a.date.localeCompare(b.date));
  // Choose last observation date as anchor to prevent current-time assumptions in history views.
  const last=dated.at(-1)?.date ?? null;
  if(!last) return {model:ANALYTICS_VERSION,lastDate:null,windowDays,metrics:METRICS,series:[],comparison:{first,second,...pearson([])},insights:[],coverage:{recordedDays:0,totalDays:0,metrics:{}}};
  const byDate = new Map(dated.map((d,i)=>[d.date,{day:d,index:i}]));
  const earliest = dateUTC(last)-(windowDays-1)*86400000;
  const series=[];
  for(let t=earliest;t<=dateUTC(last);t+=86400000) {
    const date=asDate(t), rec=byDate.get(date);
    let values=Object.fromEntries(permitted.map(k=>[k,null]));
    if(rec) {
      const day=rec.day;
      const history=dated.filter(d=>d.date<date);
      values=extract(day, scoreDay(day,history));
    }
    series.push({date,recorded:!!rec,values});
  }
  const pairs=series.filter(p=>finiteNumber(p.values[first]) && finiteNumber(p.values[second])).map(p=>[p.values[first],p.values[second]]);
  const coverage={recordedDays:series.filter(x=>x.recorded).length,totalDays:windowDays,metrics:{}};
  for(const k of permitted) coverage.metrics[k]=series.filter(x=>finiteNumber(x.values[k])).length;
  return {model:ANALYTICS_VERSION,lastDate:last,windowDays,metrics:METRICS,series,
    comparison:{first,second,...pearson(pairs),note:'Eine Korrelation ist keine Kausalität. Einflussfaktoren und Messlücken sind nicht kontrolliert.'},
    insights:describeChanges(series),coverage};
}
