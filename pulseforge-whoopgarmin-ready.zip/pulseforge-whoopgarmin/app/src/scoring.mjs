/**
 * PulseForge score engine v0.1. INDEPENDENT EXPERIMENTAL MODEL.
 * NOT Bevel's proprietary formulas; NOT clinically validated.
 * Missing measurements stay missing. No recovery score without calibration.
 */
export const MODEL_VERSION = 'pulseforge-experimental-0.1';
export const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
export function finiteNumber(x) { return typeof x === 'number' && Number.isFinite(x); }
export function median(nums) {
  const values = nums.filter(finiteNumber).sort((a, b) => a - b);
  if (!values.length) return null;
  const half = Math.floor(values.length / 2);
  return values.length % 2 ? values[half] : (values[half - 1] + values[half]) / 2;
}
export function robustBaseline(nums, minDays = 14) {
  const values = nums.filter(finiteNumber);
  if (values.length < minDays) return null;
  const center = median(values);
  const mad = median(values.map(x => Math.abs(x - center)));
  const scale = Math.max((mad || 0) * 1.4826, Math.max(0.0001, Math.abs(center) * 0.05));
  return { center, scale, count: values.length };
}
// Sleep score: duration 75%, optional sleep efficiency 25%. Method is illustrative.
export function sleepScore(day, sleepNeedMinutes = 480) {
  const mins = day?.sleep?.asleepMinutes;
  if (!finiteNumber(mins) || mins <= 0) return null;
  if (!finiteNumber(sleepNeedMinutes) || sleepNeedMinutes <= 0) return null;
  const duration = clamp(mins / sleepNeedMinutes, 0, 1);
  const inBed = day?.sleep?.inBedMinutes;
  const efficiency = finiteNumber(inBed) && inBed >= mins && inBed > 0
    ? clamp(mins / inBed, 0, 1) : null;
  const effective = efficiency == null ? duration : 0.75 * duration + 0.25 * efficiency;
  return Math.round(effective * 100);
}
export function recoveryScore(today, history, opts = {}) {
  const sleep = sleepScore(today, opts.sleepNeedMinutes ?? 480);
  const hrv = today?.night?.hrvRmssdMs;
  const rhr = today?.night?.restingHeartRateBpm;
  const recent = history.filter(x => x.date < today.date).slice(-60);
  const h = robustBaseline(recent.map(x => x.night?.hrvRmssdMs));
  const r = robustBaseline(recent.map(x => x.night?.restingHeartRateBpm));
  const missing = [];
  if (sleep == null) missing.push('sleep');
  if (!finiteNumber(hrv)) missing.push('night.hrvRmssdMs');
  if (!finiteNumber(rhr)) missing.push('night.restingHeartRateBpm');
  if (!h) missing.push('baseline.hrv_14d');
  if (!r) missing.push('baseline.rhr_14d');
  if (missing.length) return { score: null, state: 'calibrating_or_missing', missing, model: MODEL_VERSION };
  // 50 = personal baseline; sleeping poorly decreases the score.
  const hrvPoints = clamp((hrv - h.center) / h.scale, -2.5, 2.5) * 10;
  const rhrPoints = clamp((r.center - rhr) / r.scale, -2.5, 2.5) * 10;
  const sleepPoints = (sleep - 75) * 0.6;
  return {
    score: Math.round(clamp(60 + 0.38 * hrvPoints + 0.32 * rhrPoints + 0.30 * sleepPoints, 0, 100)),
    state: 'experimental', model: MODEL_VERSION,
    components: { sleepScore: sleep, hrvRmssdMs: hrv, restingHeartRateBpm: rhr },
    baseline: { hrv: h.center, rhr: r.center, daysHrv: h.count, daysRhr: r.count }
  };
}
// Weighted HR-zone minutes: a transparent LOAD PROXY, not Bevel Strain or verified TRIMP.
export function activityLoad(workout) {
  if (!Array.isArray(workout?.zoneMinutes)) return null;
  if (workout.zoneMinutes.length !== 5 || workout.zoneMinutes.some(x => !finiteNumber(x) || x < 0 || x > 1440)) return null;
  return workout.zoneMinutes.reduce((acc, minutes, index) => acc + minutes * [1, 2, 3, 5, 8][index], 0);
}
export function trainingLoad(day) {
  const loads = (day?.workouts || []).map(activityLoad).filter(finiteNumber);
  return loads.length ? Math.round(loads.reduce((a, b) => a + b, 0) * 10) / 10 : null;
}
export function cardioTrend(days, todayDate) {
  const relevant = days.filter(x => x.date <= todayDate).sort((a, b) => a.date.localeCompare(b.date));
  const last = relevant.slice(-42);
  // Require 42 DISTINCT CONTIGUOUS calendar days. A missing day is unknown, not rest/zero load.
  const stamps = last.map(d => Date.parse(`${d.date}T12:00:00Z`));
  const contiguous = stamps.length === 42 && stamps.every((t,i) => i===0 || t-stamps[i-1]===86400000);
  if (!contiguous || last.some(d => !Array.isArray(d.workouts)))
    return { atl: null, ctl: null, ratio: null, state: 'calibrating' };
  const withZero = last.map(d => trainingLoad(d) ?? 0);
  const mean = arr => arr.reduce((a, b) => a + b, 0) / arr.length;
  const atl = mean(withZero.slice(-7));
  const ctl = mean(withZero);
  return { atl: +atl.toFixed(1), ctl: +ctl.toFixed(1), ratio: ctl > 0 ? +(atl / ctl).toFixed(2) : null, state: 'experimental', model: MODEL_VERSION };
}
export function strainProxy(day) {
  const load = trainingLoad(day);
  if (load == null) return { score: null, state: 'no_hr_zone_workouts', model: MODEL_VERSION };
  // The reference load 500 is a CHOSEN calibration constant, not a Bevel constant.
  return { score: Math.round(clamp(100 * Math.log1p(load) / Math.log1p(500), 0, 130)), state: 'active_only_experimental', model: MODEL_VERSION };
}
export function scoreDay(today, history, sleepNeedMinutes = 480) {
  return {
    date: today.date,
    model: MODEL_VERSION,
    sleep: sleepScore(today, sleepNeedMinutes),
    recovery: recoveryScore(today, history, { sleepNeedMinutes }),
    strain: strainProxy(today),
    cardio: cardioTrend([...history, today], today.date),
    // Body Battery is Garmin's own value; NOT renamed Bevel Energy Bank.
    garminBodyBattery: today?.garmin?.bodyBattery ?? null,
    garminStress: today?.garmin?.stress ?? null,
    dataQuality: { sources: today.sources ?? [], missing: [
      ...(!today.sleep ? ['sleep'] : []), ...(!today.night ? ['night'] : []),
      ...(!today.workouts ? ['workouts'] : [])
    ] }
  };
}
