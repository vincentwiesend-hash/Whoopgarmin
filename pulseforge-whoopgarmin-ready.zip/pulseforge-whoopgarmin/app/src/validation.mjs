import { finiteNumber } from './scoring.mjs';
const obj = x => x && typeof x === 'object' && !Array.isArray(x);
const bounds = (x, lo, hi) => finiteNumber(x) && x >= lo && x <= hi;
const date = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && new Date(`${s}T12:00:00Z`).toISOString().slice(0, 10) === s;
export function validateDay(x) {
  if (!obj(x) || !date(x.date)) throw new Error('date: gültiges YYYY-MM-DD erforderlich');
  if (x.sources != null && (!Array.isArray(x.sources) || !x.sources.every(s => typeof s === 'string' && s.length <= 40))) throw new Error('sources ungültig');
  if (x.sleep != null) {
    if (!obj(x.sleep)) throw new Error('sleep ungültig');
    for (const k of ['asleepMinutes','inBedMinutes','deepMinutes','remMinutes','awakeMinutes'])
      if (x.sleep[k] != null && !bounds(x.sleep[k], 0, 1440)) throw new Error(`sleep.${k} ungültig`);
  }
  if (x.night != null) {
    if (!obj(x.night)) throw new Error('night ungültig');
    if (x.night.hrvRmssdMs != null && !bounds(x.night.hrvRmssdMs, 1, 500)) throw new Error('night.hrvRmssdMs ungültig');
    if (x.night.restingHeartRateBpm != null && !bounds(x.night.restingHeartRateBpm, 25, 250)) throw new Error('night.restingHeartRateBpm ungültig');
  }
  if (x.garmin != null) {
    if (!obj(x.garmin)) throw new Error('garmin ungültig');
    if (x.garmin.bodyBattery != null && !bounds(x.garmin.bodyBattery, 0, 100)) throw new Error('bodyBattery ungültig');
    if (x.garmin.stress != null && !bounds(x.garmin.stress, 0, 100)) throw new Error('stress ungültig');
    if (x.garmin.steps != null && !bounds(x.garmin.steps, 0, 300000)) throw new Error('steps ungültig');
  }
  if (x.workouts != null) {
    if (!Array.isArray(x.workouts) || x.workouts.length > 50) throw new Error('workouts ungültig');
    for (const w of x.workouts) {
      if (!obj(w) || typeof w.type !== 'string' || w.type.length > 50) throw new Error('workout type fehlt');
      if (w.zoneMinutes != null && (!Array.isArray(w.zoneMinutes) || w.zoneMinutes.length !== 5 || !w.zoneMinutes.every(v => bounds(v,0,1440)))) throw new Error('zoneMinutes muss 5 Werte enthalten');
    }
  }
  return x;
}
export function validateWatch(x) {
  if (!obj(x) || x.source !== 'connect_iq' || typeof x.device_id !== 'string' || !/^[\w-]{1,40}$/.test(x.device_id)) throw new Error('Ungültige Connect-IQ-Nachricht');
  if (!Number.isSafeInteger(x.timestamp) || Math.abs(Date.now() / 1000 - x.timestamp) > 7 * 86400) throw new Error('Zeitstempel außerhalb des Bereichs');
  const possible = {heart_rate_bpm:[0,300],body_battery:[0,100],stress:[0,100],spo2_percent:[0,100],battery_percent:[0,100],steps_today:[0,300000],calories_today_kcal:[0,100000],distance_today_cm:[0,100000000],steps_goal:[0,300000]};
  const out = {source:x.source, device_id:x.device_id, timestamp:x.timestamp};
  for (const [k, [lo,hi]] of Object.entries(possible)) if (x[k] != null) {
    if (!bounds(x[k],lo,hi)) throw new Error(`Ungültiges ${k}`);
    out[k] = x[k];
  }
  return out;
}
