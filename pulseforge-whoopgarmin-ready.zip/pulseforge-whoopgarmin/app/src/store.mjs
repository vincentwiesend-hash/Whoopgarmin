import fs from 'node:fs';
import path from 'node:path';
export function createStore(file) {
  function read() {
    if (!fs.existsSync(file)) return { days: {}, watch: {}, logs: [] };
    const x = JSON.parse(fs.readFileSync(file, 'utf8'));
    return { days: x.days ?? {}, watch: x.watch ?? {}, logs: x.logs ?? [] };
  }
  function write(x) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(x, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
  }
  return {
    read,
    upsertDay(day) { const d = read(); d.days[day.date] = { ...(d.days[day.date] ?? {}), ...day }; write(d); return d.days[day.date]; },
    upsertWatch(sample) {
      const d = read(); const key = `${sample.device_id}:${sample.timestamp}`;
      if (d.watch[key]) return false;
      d.watch[key] = sample;
      // DEMO only: cap snapshots so the JSON file doesn't grow forever.
      const keys = Object.keys(d.watch).sort((a,b) => (d.watch[a].timestamp - d.watch[b].timestamp));
      for (const k of keys.slice(0, -3000)) delete d.watch[k];
      write(d); return true;
    },
    clear() { write({ days: {}, watch: {}, logs: [] }); }
  };
}
