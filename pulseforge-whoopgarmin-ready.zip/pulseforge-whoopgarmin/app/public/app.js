// No third-party source code. Visualizations never invent live measurements.
const qs = selector => document.querySelector(selector);
const navigation=qs('#navigation'),content=qs('#content'),heading=qs('#heading'),mode=qs('#mode');
const headings={overview:'Dein Tag im Überblick',recovery:'Recovery & Baseline',sleep:'Schlaf & Regeneration',fitness:'Training & Fitness',trends:'Deine Trends',compare:'Metriken vergleichen',insights:'Deine Erkenntnisse',strength:'Strength Builder',sources:'Datenquellen & Qualität'};
const META={hrv:['Nächtliche HRV','ms'],rhr:['Ruhepuls','bpm'],sleepMinutes:['Schlafdauer','min'],sleepScore:['Schlafscore · experimentell','/100'],recovery:['Recovery · experimentell','/100'],strain:['Trainingsbelastung · Proxy','/100+'],trainingLoad:['HF-Zonenlast · Proxy','Punkte'],steps:['Schritte',''],stress:['Garmin Stress','/100'],bodyBattery:['Garmin Body Battery','/100']};
const metrics=Object.keys(META);
let tab='overview',current=null,analytics=null,watchLatest=null,real=false,readToken='',viewDays=28,chosenMetric='hrv',firstMetric='hrv',secondMetric='rhr';
const example={day:{date:'2026-10-28',sleep:{asleepMinutes:451,inBedMinutes:487,deepMinutes:87,remMinutes:107},night:{hrvRmssdMs:54,restingHeartRateBpm:51},garmin:{steps:7842,bodyBattery:72,stress:29},workouts:[{type:'Laufen',zoneMinutes:[8,12,19,9,1]}],sources:['DEMO/SYNTHETISCH']},scores:{date:'2026-10-28',sleep:91,recovery:{score:76,state:'synthetic_demo',baseline:{hrv:50,rhr:52,daysHrv:30,daysRhr:30}},strain:{score:61,state:'synthetic_demo'},cardio:{atl:83,ctl:69,ratio:1.2,state:'synthetic_demo'},garminBodyBattery:72,garminStress:29,dataQuality:{sources:['DEMO/SYNTHETISCH'],missing:[]}}};
const numeric=n=>typeof n==='number'&&Number.isFinite(n);
const esc=s=>String(s??'—').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const fmt=(x,suffix='')=>numeric(x)?`${esc(Number.isInteger(x)?x:x.toFixed(1))}${suffix}`:'—';
const box=(title,inner)=>`<article class="panel"><h2>${esc(title)}</h2>${inner}</article>`;
const kpi=(label,value,unit='')=>`<div class="kpi"><label>${esc(label)}</label><b>${fmt(value)}</b><small>${esc(unit)}</small></div>`;
const badge=(v)=>v==null?'Daten fehlen':'Experimenteller Indikator · nicht klinisch';
const card=(label,value,description,color)=>{const pct=numeric(value)?Math.max(0,Math.min(100,value)):0;return `<div class="score"><div class="ring"><svg viewBox="0 0 120 120" role="img" aria-label="${esc(label)}: ${fmt(value,'%')}"><circle class="dial-track" cx="60" cy="60" r="49" pathLength="100"/><circle class="dial-fill" cx="60" cy="60" r="49" pathLength="100" stroke="${esc(color)}" stroke-dasharray="${pct} 100"/></svg><strong>${fmt(value,'%')}</strong></div><div><h2>${esc(label)}</h2><p>${esc(description)}</p><span class="pill">${badge(value)}</span></div></div>`;};
const metricOptions=selected=>metrics.map(key=>`<option value="${key}" ${key===selected?'selected':''}>${esc(META[key][0])}</option>`).join('');
const available=()=>analytics?.series ?? [];
const currentSeries=()=>available().slice(-viewDays);
const picked=(series,metric)=>series.filter(p=>numeric(p.values?.[metric]));
const demoAnalytics=()=>{
 const series=[];const end=Date.parse('2026-10-28T12:00:00Z');
 for(let i=0;i<90;i++){
  const date=new Date(end-(89-i)*86400000).toISOString().slice(0,10);
  const wave=Math.sin(i/4),hrv=49+wave*5+(i%3),rhr=52-wave*2,sl=420+wave*18+(i%4)*9;
  series.push({date,recorded:true,values:{hrv:Math.round(hrv*10)/10,rhr:Math.round(rhr*10)/10,sleepMinutes:Math.round(sl),sleepScore:Math.round(sl/480*100),recovery: i>=14?Math.round(68+wave*9):null,strain:Math.round(56+wave*14),trainingLoad:120+wave*30,steps:7000+i*9+Math.round(wave*600),stress:30-Math.round(wave*8),bodyBattery:60+Math.round(wave*12)}});
 }
 return {lastDate:'2026-10-28',series,insights:[{statement:'DEMO: Nächtliche HRV und Schlafdauer sind im Beispiel zuletzt gestiegen. Keine reale Aussage.'}],model:'synthetische Demo',comparison:{first:firstMetric,second:secondMetric,r:null,n:0,state:'demo_only'},coverage:{recordedDays:90,totalDays:90,metrics:{}}};
};
const joinSegments=(series,metric,width=520,height=170)=>{
 const vals=series.map(x=>numeric(x.values?.[metric])?x.values[metric]:null);
 const known=vals.filter(numeric);
 if(!known.length)return {path:'',min:null,max:null,n:0};
 const vMin=Math.min(...known),vMax=Math.max(...known),pad=Math.max((vMax-vMin)*0.1,1);
 const lo=vMin-pad,hi=vMax+pad;
 let path='';
 vals.forEach((v,i)=>{
  if(v==null) return;
  const x=(i/Math.max(series.length-1,1)*width).toFixed(2),y=(height-(v-lo)/(hi-lo)*height).toFixed(2);
  path+=`${i>0&&vals[i-1]!=null?' L':' M'}${x} ${y}`;
 });
 return {path,min:vMin,max:vMax,n:known.length};
};
function plotMetric(series,metric,title,alt=false){
 const val=joinSegments(series,metric);
 if(!val.path) return `<div class="empty">${esc(title)}: Keine Messwerte für diesen Zeitraum.</div>`;
 return `<div class="chart-wrap"><svg class="chart actual" role="img" aria-label="${esc(title)}, ${val.n} vorhandene Werte" viewBox="0 0 560 200" preserveAspectRatio="none"><path class="grid" d="M0 45H560M0 100H560M0 155H560"/><path class="line-chart ${alt?'alt':''}" transform="translate(20 12) scale(1 1)" d="${val.path}"/></svg><div class="chart-labels"><span>${esc(series[0]?.date||'')}</span><span>${val.n} Werte · ${fmt(val.min)}–${fmt(val.max)} ${esc(META[metric][1])}</span><span>${esc(series.at(-1)?.date||'')}</span></div></div>`;
}
function pairedPlot(series,a,b){
 const pa=joinSegments(series,a),pb=joinSegments(series,b);
 if(!pa.path||!pb.path)return '<div class="empty">Für mindestens eine der Metriken fehlen Messwerte.</div>';
 // Each line is displayed on its own y-scale, marked clearly: compare correlations, NOT absolute magnitude.
 const normalize=(metric)=>{
  const values=series.map(x=>numeric(x.values?.[metric])?x.values[metric]:null),valid=values.filter(numeric),lo=Math.min(...valid),hi=Math.max(...valid);
  return values.map((v,i)=>v==null?null:[i/Math.max(values.length-1,1)*520,(hi===lo?85:170-(v-lo)/(hi-lo)*170)]);
 };
 const path=coords=>coords.map((xy,i)=>xy?`${coords[i-1]?'L':'M'}${xy[0].toFixed(1)} ${xy[1].toFixed(1)}`:'').join(' ');
 return `<div class="chart-wrap"><svg class="chart actual" role="img" aria-label="Normalisierte Vergleichslinien ohne gemeinsame Einheit" viewBox="0 0 560 200" preserveAspectRatio="none"><path class="grid" d="M0 45H560M0 100H560M0 155H560"/><path transform="translate(20 12)" class="line-chart" d="${path(normalize(a))}"/><path transform="translate(20 12)" class="line-chart alt" d="${path(normalize(b))}"/></svg><div class="chart-labels"><span>${esc(series[0]?.date||'')}</span><span>Unabhängige y-Skalen · keine absoluten Werte vergleichen</span><span>${esc(series.at(-1)?.date||'')}</span></div></div>`;
}
const windowOptions=()=>[7,14,28,42,90].map(n=>`<option value="${n}" ${n===viewDays?'selected':''}>${n} Tage</option>`).join('');
function descriptiveComparison(series,a,b){
 const pairs=series.map(x=>[x.values?.[a],x.values?.[b]]).filter(p=>p.every(numeric));const n=pairs.length;
 if(n<7)return {r:null,n,state:'insufficient_pairs'};
 const ma=pairs.reduce((s,p)=>s+p[0],0)/n,mb=pairs.reduce((s,p)=>s+p[1],0)/n;
 let sa=0,sb=0,cross=0;
 for(const [x,y] of pairs){sa+=(x-ma)**2;sb+=(y-mb)**2;cross+=(x-ma)*(y-mb);}
 if(!sa||!sb)return {r:null,n,state:'no_variation'};
 return {r:Math.round(cross/Math.sqrt(sa*sb)*100)/100,n,state:real?'descriptive_only':'demo_only'};
}
function render(){
 [...navigation.querySelectorAll('button')].forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 heading.textContent=headings[tab];
 const x=current||example,d=x.day,s=x.scores,series=currentSeries();
 const warning=`<div class="note">${real?'Echte, lokal importierte Werte. Scores sind experimentell; fehlende Messungen werden nicht ersetzt.':'DEMO-MODUS: Alle Messwerte, Kurven und Erkenntnisse sind synthetisch. Mit Lesetoken echte Daten laden.'}</div>`;
 if(tab==='overview')content.innerHTML=warning+`<div class="stats">${card('Strain (aktive Last)',s.strain?.score,'Aus HF-Zonenminuten; kein Bevel-Score','#e6a65c')}${card('Recovery',s.recovery?.score,'Nächtliche HRV, Ruhepuls und Schlaf','#6bd7a4')}${card('Sleep',s.sleep,'Dauer und Effizienz','#8aa4ef')}</div><div class="two">${box('Garmin-Werte',`<div class="kpi-grid">${kpi('Body Battery',s.garminBodyBattery,'/100')}${kpi('Garmin Stress',s.garminStress,'/100')}${kpi('Schritte',d.garmin?.steps)}</div><p>Body Battery ist ein Garmin-Wert, kein Bevel Energy Bank.</p>`)}${box('HRV-Trend',plotMetric(series,'hrv','HRV-Verlauf'))}</div>${real?box('Letzter Connect-IQ-Upload',watchLatest?`<div class="kpi-grid">${kpi('Herzfrequenz',watchLatest.heart_rate_bpm,'bpm')}${kpi('Uhrenakku',watchLatest.battery_percent,'%')}${kpi('Schritte',watchLatest.steps_today)}</div><p>Letzter Upload: ${esc(new Date(watchLatest.timestamp*1000).toLocaleString('de-DE'))}. Nur ein gespeicherter Snapshot, kein Live-Stream.</p>`:'<div class="empty">Noch kein Connect-IQ-Upload eingegangen.</div>'):''}`;
 if(tab==='recovery')content.innerHTML=warning+`<div class="two">${box('Erholung',card('Recovery',s.recovery?.score,'14+ verschiedene Nächte zur Kalibrierung erforderlich','#70ddab'))}${box('Nächtliche Biomarker',`<div class="kpi-grid">${kpi('HRV (RMSSD)',d.night?.hrvRmssdMs,'ms')}${kpi('Ruhepuls',d.night?.restingHeartRateBpm,'bpm')}${kpi('Kalibrierungstage',s.recovery?.baseline?.daysHrv)}</div><p>Score ist unvalidiert und nicht für medizinische Entscheidungen geeignet.</p>`)}</div>`;
 if(tab==='sleep')content.innerHTML=warning+`<div class="two">${box('Schlaf',`<div class="kpi-grid">${kpi('Geschlafen',d.sleep?.asleepMinutes,'min')}${kpi('Im Bett',d.sleep?.inBedMinutes,'min')}${kpi('Schlafscore',s.sleep,'/100')}${kpi('Tiefschlaf',d.sleep?.deepMinutes,'min')}${kpi('REM',d.sleep?.remMinutes,'min')}</div>`)}${box('Schlafdauer im Zeitverlauf',plotMetric(series,'sleepMinutes','Schlafdauer'))}</div>`;
 if(tab==='fitness')content.innerHTML=warning+`<div class="two">${box('Trainingslast',`<div class="kpi-grid">${kpi('ATL 7 Tage',s.cardio?.atl,'Punkte')}${kpi('CTL 42 Tage',s.cardio?.ctl,'Punkte')}${kpi('Verhältnis',s.cardio?.ratio)}</div><p>Experimenteller HF-Zonen-Proxy; ausdrücklich nicht Garmins Training Load.</p>`)}${box('Workouts',`<div class="time-list">${(d.workouts||[]).map(w=>`<div class="event"><strong>${esc(w.type)}</strong><span>${fmt(w.zoneMinutes?.reduce((a,b)=>a+b,0))} min</span></div>`).join('')||'<p>Keine Workouts vorhanden.</p>'}</div>`)}</div>`;
 if(tab==='trends'){
  const valid=picked(series,chosenMetric);const avg=valid.length?valid.reduce((t,p)=>t+p.values[chosenMetric],0)/valid.length:null;
  content.innerHTML=warning+box('Zeitverlauf',`<div class="controls"><label>Metrik<select id="trendMetric">${metricOptions(chosenMetric)}</select></label><label>Zeitraum<select id="trendDays">${windowOptions()}</select></label></div><div class="kpi-grid">${kpi('Messwerte',valid.length,`von ${series.length} Tagen`)}${kpi('Durchschnitt',avg,META[chosenMetric][1])}${kpi('Letzter Wert',valid.at(-1)?.values[chosenMetric],META[chosenMetric][1])}</div>${plotMetric(series,chosenMetric,META[chosenMetric][0])}<p>Bei Datenlücken bleibt die Kurve unterbrochen. Keine Extrapolation oder Auffüllung.</p>`);
 }
 if(tab==='compare'){
  const c=descriptiveComparison(series,firstMetric,secondMetric);
  content.innerHTML=warning+box('Zwei Metriken vergleichen',`<div class="controls"><label>Erste Metrik<select id="compareFirst">${metricOptions(firstMetric)}</select></label><label>Zweite Metrik<select id="compareSecond">${metricOptions(secondMetric)}</select></label><label>Zeitraum<select id="compareDays">${windowOptions()}</select></label></div>${pairedPlot(series,firstMetric,secondMetric)}<div class="kpi-grid">${kpi('Korrelation r',firstMetric===secondMetric?null:c.r,'Pearson')}${kpi('Gemeinsame Datenpunkte',c.n,'Tage')}</div><p>${firstMetric===secondMetric?'Bitte zwei unterschiedliche Metriken wählen.':c.state==='insufficient_pairs'?'Mindestens sieben gemeinsame Messwertpaare erforderlich.':c.state==='no_variation'?'Eine Metrik variiert im Zeitraum nicht.':'Nur eine deskriptive Korrelation: keine Kausalität, keine individuelle Risikoaussage.'}</p>`);
 }
 if(tab==='insights'){
  const insights=analytics?.insights||[];
  content.innerHTML=warning+box('Beschreibende Wochenvergleiche',`<p>Verglichen werden zwei getrennte 7-Tage-Perioden mit mindestens fünf Messungen je Metrik. Aus den Zahlen werden weder Diagnosen noch Kausalzusammenhänge abgeleitet.</p>${insights.length?`<ul class="list">${insights.map(i=>`<li>${esc(i.statement)}</li>`).join('')}</ul>`:'<div class="empty">Noch zu wenige vollständige Vergleichsperioden. Es werden keine Erkenntnisse erfunden.</div>'}`);
 }
 if(tab==='strength')content.innerHTML=warning+box('Strength Builder – Planung',`<ul class="list"><li>Trainingsplan / Einheit / Übung / Satz</li><li>Gewicht, Wiederholungen, RIR, Satztyp und Timer</li><li>Muskelgruppen und Trainingsvolumen</li><li>Duplikate mit Garmin-Workouts erkennen</li></ul><p>Workout-Editor ist noch nicht implementiert.</p>`);
 if(tab==='sources'){
  const coverage=series.length?series.filter(p=>p.recorded).length:0;
  content.innerHTML=warning+box('Herkunft und Datenqualität',`<div class="kpi-grid">${kpi('Tage mit Datensatz',coverage,`von ${series.length}`)}${kpi('Tage mit HRV',picked(series,'hrv').length,`von ${series.length}`)}${kpi('Tage mit Schlaf',picked(series,'sleepMinutes').length,`von ${series.length}`)}</div><table class="table"><thead><tr><th>Feld</th><th>Wert</th><th>Quelle</th></tr></thead><tbody>${[['Datum',d.date],['HRV RMSSD',d.night?.hrvRmssdMs],['Ruhepuls',d.night?.restingHeartRateBpm],['Schlafminuten',d.sleep?.asleepMinutes],['Body Battery',s.garminBodyBattery],['Stress',s.garminStress]].map(([a,b])=>`<tr><td>${esc(a)}</td><td>${esc(b)}</td><td>${esc(d.sources?.join(', ')||'Unbekannt')}</td></tr>`).join('')}</tbody></table><p>Garmin-Rohdaten-Mappings bleiben vor einer produktiven Nutzung anhand realer API-Antworten zu prüfen.</p>`);
 }
}
async function loadReal(){
 const token=readToken;
 const [r1,r2,r3]=await Promise.all([
  fetch('/api/v1/summary',{headers:{'X-Read-Token':token},cache:'no-store'}),
  fetch('/api/v1/analytics?days=90',{headers:{'X-Read-Token':token},cache:'no-store'}),
  fetch('/api/v1/watch/latest',{headers:{'X-Read-Token':token},cache:'no-store'})
 ]);
 if(!r1.ok||!r2.ok) throw new Error(`API-Fehler ${!r1.ok?r1.status:r2.status}`);
 const [a,b,c]=await Promise.all([r1.json(),r2.json(),r3.ok?r3.json():Promise.resolve({data:null})]);
 if(!a.data && !c.data)throw new Error('Noch keine importierten Tagesdaten oder Uhren-Snapshots');
 // A watch-only account must never silently show the synthetic example day.
 current=a.data||{day:{date:'—',sources:['connect_iq (nur Snapshot)']},scores:{sleep:null,recovery:{score:null},strain:{score:null},cardio:{atl:null,ctl:null,ratio:null},garminBodyBattery:null,garminStress:null}};
 analytics=b.data;watchLatest=c.data;real=true;
}
navigation.addEventListener('click',e=>{const b=e.target.closest('button[data-tab]');if(b){tab=b.dataset.tab;render();}});
content.addEventListener('change',e=>{
 const id=e.target.id,v=e.target.value;
 if(id==='trendMetric'&&metrics.includes(v))chosenMetric=v;
 if(id==='compareFirst'&&metrics.includes(v))firstMetric=v;
 if(id==='compareSecond'&&metrics.includes(v))secondMetric=v;
 if(['trendDays','compareDays'].includes(id)&&[7,14,28,42,90].includes(Number(v)))viewDays=Number(v);
 render();
});
qs('#loadBtn').addEventListener('click',async()=>{
 readToken=qs('#readToken').value.trim();
 if(!readToken){real=false;current=null;watchLatest=null;analytics=demoAnalytics();mode.className='mode demo';mode.textContent='DEMO · fiktive Werte';render();return;}
 try{await loadReal();mode.className='mode real';mode.textContent='LOKALE DATEN · authentifiziert';}
 catch(e){real=false;current=null;watchLatest=null;analytics=null;mode.className='mode demo';mode.textContent='Fehler: '+String(e.message);}
 render();
});
analytics=demoAnalytics();render();
