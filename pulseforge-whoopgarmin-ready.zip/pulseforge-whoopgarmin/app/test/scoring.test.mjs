import test from 'node:test';
import assert from 'node:assert/strict';
import { sleepScore, median, robustBaseline, recoveryScore, strainProxy, cardioTrend, scoreDay } from '../src/scoring.mjs';
import { validateDay, validateWatch } from '../src/validation.mjs';
test('missing data is not magically 100%',()=>{
 assert.equal(sleepScore({}),null);
 const r = recoveryScore({date:'2026-10-28'},[]);
 assert.equal(r.score,null);
 assert.ok(r.missing.includes('baseline.hrv_14d'));
});
test('sleep needs valid duration and respects bounds',()=>{
 assert.equal(sleepScore({sleep:{asleepMinutes:480,inBedMinutes:500}}),99);
 assert.equal(sleepScore({sleep:{asleepMinutes:480}}),100);
 assert.equal(sleepScore({sleep:{asleepMinutes:0}}),null);
});
test('robust baseline avoids a single extreme value',()=>{
 assert.equal(median([1,2,3,999]),2.5);
 const b=robustBaseline(Array(18).fill(55).concat([500]));
 assert.ok(b.center<60);
});
test('calibrated recovery uses night values',()=>{
 const h=Array.from({length:30},(_,i)=>({date:`2026-09-${String(i+1).padStart(2,'0')}`,night:{hrvRmssdMs:52+i%5,restingHeartRateBpm:51+i%4},sleep:{asleepMinutes:465,inBedMinutes:500},workouts:[]}));
 const t={date:'2026-10-01',night:{hrvRmssdMs:60,restingHeartRateBpm:49},sleep:{asleepMinutes:480,inBedMinutes:500},workouts:[{type:'run',zoneMinutes:[10,10,20,5,0]}]};
 const r=recoveryScore(t,h);assert.ok(r.score>=0&&r.score<=100);
 assert.ok(strainProxy(t).score>0);
 assert.equal(scoreDay(t,h).date,t.date);
});
test('training load does not mistake missing calendar days for rest',()=>{
 const first = Date.parse('2026-09-01T12:00:00Z');
 const ds = Array.from({length:42},(_,i)=>({date:new Date(first+(i+(i>=20?1:0))*86400000).toISOString().slice(0,10),workouts:[]}));
 assert.equal(cardioTrend(ds, ds.at(-1).date).state, 'calibrating');
});
test('ATL requires enough daily records',()=>{
 assert.equal(cardioTrend([], '2026-10-28').state,'calibrating');
});
test('validated records are restrictive',()=>{
 assert.throws(()=>validateDay({date:'2026-02-30'}));
 assert.throws(()=>validateDay({date:'2026-10-28',night:{hrvRmssdMs:-1}}));
 assert.throws(()=>validateWatch({source:'connect_iq',device_id:'x',timestamp:0}));
});
