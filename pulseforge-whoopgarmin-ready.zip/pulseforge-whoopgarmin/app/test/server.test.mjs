import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
async function ephemeralPort(){return await new Promise((ok,no)=>{const s=net.createServer();s.on('error',no);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>ok(p));});});}
test('HTTP API requires correct tokens, saves and reads day', async t=>{
 const dir=mkdtempSync(path.join(tmpdir(),'pulseforge-test-'));
 const port=await ephemeralPort();
 const tokens={READ_TOKEN:'r'.repeat(32),ADMIN_TOKEN:'a'.repeat(32),INGEST_TOKEN:'i'.repeat(32)};
 const proc=spawn(process.execPath,['server.mjs'],{cwd:path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'),env:{...process.env,...tokens,PORT:String(port),DATA_FILE:path.join(dir,'store.json')},stdio:'ignore'});
 t.after(()=>{proc.kill();rmSync(dir,{recursive:true,force:true});});
 const url=`http://127.0.0.1:${port}`;
 let live=false;
 for(let i=0;i<90;i++){
   try{const r=await fetch(url+'/healthz');if(r.ok){live=true;break;}}catch{}
   await new Promise(r=>setTimeout(r,20));
 }
 assert.equal(live,true,'server started');
 assert.equal((await fetch(url+'/api/v1/summary')).status,401);
 assert.equal((await fetch(url+'/api/v1/analytics?days=28')).status,401);
 const payload={date:'2026-10-28',sources:['fixture'],sleep:{asleepMinutes:440,inBedMinutes:500},night:{hrvRmssdMs:55,restingHeartRateBpm:51},workouts:[]};
 assert.equal((await fetch(url+'/api/v1/days',{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Token':'bad'},body:JSON.stringify(payload)})).status,401);
 assert.equal((await fetch(url+'/api/v1/days',{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Token':tokens.ADMIN_TOKEN},body:JSON.stringify(payload)})).status,200);
 const r=await fetch(url+'/api/v1/summary',{headers:{'X-Read-Token':tokens.READ_TOKEN}});assert.equal(r.status,200);
 const j=await r.json(); assert.equal(j.data.day.date,payload.date);assert.equal(j.data.scores.recovery.score,null);
 const r2=await fetch(url+'/api/v1/analytics?days=28',{headers:{'X-Read-Token':tokens.READ_TOKEN}});
 assert.equal(r2.status,200);const analytics=await r2.json();
 assert.equal(analytics.data.coverage.recordedDays,1);
 assert.equal(analytics.data.series.length,28);
 assert.equal(analytics.data.comparison.state,'insufficient_pairs');
 const watch={source:'connect_iq',device_id:'fenix_test',timestamp:Math.floor(Date.now()/1000),heart_rate_bpm:64,battery_percent:55};
 const submit=()=>fetch(url+'/api/v1/watch',{method:'POST',headers:{'Content-Type':'application/json','X-Device-Token':tokens.INGEST_TOKEN},body:JSON.stringify(watch)});
 assert.equal((await submit()).status,200);
 const duplicate=await submit(); assert.equal((await duplicate.json()).inserted,false);
 const latest=await fetch(url+'/api/v1/watch/latest',{headers:{'X-Read-Token':tokens.READ_TOKEN}});
 assert.equal((await latest.json()).data.device_id,'fenix_test');
 assert.equal((await fetch(url+'/api/v1/analytics?days=500',{headers:{'X-Read-Token':tokens.READ_TOKEN}})).status,400);
});
