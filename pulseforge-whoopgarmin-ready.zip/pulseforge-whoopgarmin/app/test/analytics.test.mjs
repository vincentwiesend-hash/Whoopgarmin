import test from 'node:test';
import assert from 'node:assert/strict';
import {buildAnalytics,pearson,describeChanges,METRICS} from '../src/analytics.mjs';
const day=(date,offset=0)=>({date,sources:['test'],night:{hrvRmssdMs:55+offset,restingHeartRateBpm:52-offset/2},sleep:{asleepMinutes:440+offset,inBedMinutes:480},garmin:{steps:7000+offset*100,stress:30,bodyBattery:60},workouts:[]});
const date = i => new Date(Date.UTC(2026,8,1+i,12)).toISOString().slice(0,10);
test('Pearson math: perfect positive, inverse, gaps and constant data',()=>{
 assert.deepEqual(pearson([[1,2],[2,4],[3,6],[4,8],[5,10],[6,12],[7,14]]),{r:1,n:7,state:'descriptive_only'});
 assert.equal(pearson(Array.from({length:7},(_,i)=>[i,7-i])).r,-1);
 assert.equal(pearson([[1,2],[2,null]]).state,'insufficient_pairs');
 assert.equal(pearson(Array.from({length:7},(_,i)=>[1,i])).state,'no_variation');
});
test('daily series preserves missing days and never fabricates samples',()=>{
 const r=buildAnalytics([day(date(0)),day(date(2))],{windowDays:7});
 assert.equal(r.lastDate,date(2));
 assert.equal(r.coverage.recordedDays,2);
 assert.equal(r.series.length,7);
 assert.equal(r.series.at(-2).recorded,false);
 assert.equal(r.series.at(-2).values.hrv,null);
 assert.equal(r.comparison.state,'insufficient_pairs');
});
test('recovery stays unavailable until 14 historical valid dates',()=>{
 const ds=Array.from({length:17},(_,i)=>day(date(i),i%5));
 const r=buildAnalytics(ds,{windowDays:28,first:'hrv',second:'rhr'});
 assert.equal(r.coverage.metrics.recovery,3);
 assert.equal(r.comparison.state,'descriptive_only');
 assert.ok(r.insights.length>=2);
 assert.equal(r.series.at(-1).values.recovery!==null,true);
});
test('short history does not produce comparison insights',()=>{
 const ds=Array.from({length:8},(_,i)=>day(date(i),i));
 const r=buildAnalytics(ds,{windowDays:28});
 assert.equal(r.insights.length,0);
 assert.equal(describeChanges([]).length,0);
 assert.equal(Object.hasOwn(METRICS,'hrv'),true);
});
test('unsupported metric selection falls back to registered fields',()=>{
 const r=buildAnalytics([day(date(0))],{first:'__proto__',second:'notAMetric',windowDays:28});
 assert.equal(r.comparison.first,'hrv');assert.equal(r.comparison.second,'rhr');
});
