import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { timingSafeEqual } from 'node:crypto';
import { createStore } from './src/store.mjs';
import { scoreDay } from './src/scoring.mjs';
import { buildAnalytics } from './src/analytics.mjs';
import { validateDay, validateWatch } from './src/validation.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const store = createStore(process.env.DATA_FILE || path.join(root, 'data', 'private.json'));
const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 3477);
const READ = process.env.READ_TOKEN;
const ADMIN = process.env.ADMIN_TOKEN;
const DEVICE = process.env.INGEST_TOKEN;
if ([READ,ADMIN,DEVICE].some(x => !x || x.length < 24) || new Set([READ,ADMIN,DEVICE]).size !== 3) {
  console.error('READ_TOKEN, ADMIN_TOKEN, INGEST_TOKEN: jeweils >=24 Zeichen, alle verschieden.');
  process.exit(1);
}
const okToken = (seen, expected) => {
  if (typeof seen !== 'string') return false;
  const a=Buffer.from(seen), b=Buffer.from(expected);
  return a.length===b.length && timingSafeEqual(a,b);
};
function json(res,status,data) {
  res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer'});
  res.end(JSON.stringify(data));
}
async function body(req) {
  if (!String(req.headers['content-type']||'').toLowerCase().startsWith('application/json')) throw new Error('Content-Type application/json erforderlich');
  let n=0, s='';
  for await (const chunk of req) {
    n+=chunk.length;
    if (n>65536) throw new Error('Maximal 64 KiB');
    s+=chunk;
  }
  return JSON.parse(s);
}
function serve(res,route) {
  const mapping={'/':'index.html','/app.js':'app.js','/style.css':'style.css'};
  const file=mapping[route];
  if (!file) return json(res,404,{error:'Not found'});
  const ctype=file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8';
  res.writeHead(200,{'content-type':ctype,'cache-control':'no-store','content-security-policy':"default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",'referrer-policy':'no-referrer'});
  fs.createReadStream(path.join(root,'public',file)).pipe(res);
}
const server=http.createServer(async (req,res)=>{
  const u=new URL(req.url,`http://${HOST}:${PORT}`);
  if(req.method==='GET'&&u.pathname==='/healthz') return json(res,200,{ok:true,service:'pulseforge-lab'});
  if(req.method==='GET'&&['/','/app.js','/style.css'].includes(u.pathname)) return serve(res,u.pathname);
  if(req.method==='POST'&&(u.pathname==='/api/v1/watch'||u.pathname==='/api/garmin/ingest')) {
    if(!okToken(req.headers['x-device-token'],DEVICE)) return json(res,401,{error:'Unauthorized'});
    try {const p=validateWatch(await body(req)); return json(res,200,{ok:true,inserted:store.upsertWatch(p)});}
    catch(e){return json(res,400,{error:e.message});}
  }
  if(req.method==='POST'&&u.pathname==='/api/v1/days') {
    if(!okToken(req.headers['x-admin-token'],ADMIN)) return json(res,401,{error:'Unauthorized'});
    try{const day=validateDay(await body(req));store.upsertDay(day);return json(res,200,{ok:true,date:day.date});}
    catch(e){return json(res,400,{error:e.message});}
  }
  if(req.method==='GET'&&u.pathname.startsWith('/api/v1/')) {
    if(!okToken(req.headers['x-read-token'],READ)) return json(res,401,{error:'Unauthorized'});
    const x=store.read(); const days=Object.values(x.days).sort((a,b)=>a.date.localeCompare(b.date));
    if(u.pathname==='/api/v1/days') return json(res,200,{data:days});
    if(u.pathname==='/api/v1/analytics') {
      const windowDays = Number(u.searchParams.get('days') || 28);
      if (![7,14,28,42,90].includes(windowDays)) return json(res,400,{error:'days muss 7,14,28,42 oder 90 sein'});
      return json(res,200,{data:buildAnalytics(days,{windowDays,first:u.searchParams.get('first'),second:u.searchParams.get('second')})});
    }
    if(u.pathname==='/api/v1/summary') {
      const date=u.searchParams.get('date')||days.at(-1)?.date;
      const today=days.find(d=>d.date===date);
      return json(res,200,{data:today?{day:today,scores:scoreDay(today,days.filter(d=>d.date<date))}:null});
    }
    if(u.pathname==='/api/v1/watch/latest') {
      const arr=Object.values(x.watch).sort((a,b)=>a.timestamp-b.timestamp);
      return json(res,200,{data:arr.at(-1)||null});
    }
    return json(res,404,{error:'Not found'});
  }
  return json(res,404,{error:'Not found'});
});
server.listen(PORT,HOST,()=>console.log(`PulseForge local prototype: http://${HOST}:${PORT}`));
