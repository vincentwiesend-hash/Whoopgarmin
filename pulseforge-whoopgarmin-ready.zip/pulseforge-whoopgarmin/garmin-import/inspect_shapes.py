"""Print JSON key paths only; values are never printed."""
import json
import sys
from pathlib import Path

def paths(x, prefix='', depth=0):
    if depth > 4:
        return
    if isinstance(x, dict):
        for k, v in x.items():
            p = f'{prefix}.{k}' if prefix else k
            print(p)
            paths(v, p, depth + 1)
    elif isinstance(x, list) and x:
        paths(x[0], prefix + '[]', depth+1)

if __name__=='__main__':
    for name in sys.argv[1:]:
        print(f'=== {Path(name).name} (keys only) ===')
        paths(json.loads(Path(name).read_text()))
