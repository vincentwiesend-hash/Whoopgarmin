"""Fetch *your own* Garmin Personal API data via Garmin's official Python client.

No keys or access tokens are logged or written by this file. The Garmin client
may cache an access token under ~/.config/garmin; protect that directory.
Raw JSON is sensitive. Never commit data/raw to git or upload to public services.
"""
import argparse
import json
import os
from datetime import date, timedelta
from pathlib import Path

from garmin_personal_api import GarminPersonalApiClient, PersonalApiAuthenticator, resolve_api_key


def persist(root: Path, day: date, category: str, value) -> None:
    folder = root / day.isoformat()
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = folder / f"{category}.json"
    # Use O_EXCL to avoid leaking or clobbering older snapshots silently.
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(target, flags, 0o600)
    except FileExistsError:
        print(f"Skipped existing {day}/{category}")
        return
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)


def main():
    p = argparse.ArgumentParser(description="Personal Garmin Connect export (private use only)")
    p.add_argument('--start', required=True, help='YYYY-MM-DD')
    p.add_argument('--end', required=True, help='YYYY-MM-DD')
    p.add_argument('--out', default='../data/raw/garmin')
    args = p.parse_args()
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    if end < start or (end-start).days > 30:
        p.error('A single run supports 1–31 days (inclusive).')
    root = Path(args.out).expanduser()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    with PersonalApiAuthenticator() as auth:
        token = auth.obtain_token(resolve_api_key())
    with GarminPersonalApiClient(token.access_token) as client:
        day = start
        while day <= end:
            iso = day.isoformat()
            # Per-day wrappers are documented in Garmin's official repository.
            for name, method in (
                ('sleep', lambda: client.get_daily_sleep(iso)),
                ('hrv', lambda: client.get_daily_hrv(iso)),
                ('heart_rate', lambda: client.get_daily_heart_rate(iso)),
            ):
                try:
                    persist(root, day, name, method())
                    print(f'Saved/checked {iso}/{name}')
                except Exception as err:
                    # Never log API responses or credentials.
                    print(f'FAILED {iso}/{name}: {type(err).__name__}')
            day += timedelta(days=1)
        try:
            # Copies window-level summaries to the start day's directory by convention.
            persist(root, start, 'daily_summaries', client.get_daily_summaries(start.isoformat(), end.isoformat()))
            persist(root, start, 'body_battery_window', client.get_daily_body_battery(start.isoformat(), end.isoformat()))
            persist(root, start, 'daily_stress_window', client.get_daily_stress(start.isoformat(), end.isoformat()))
            print('Saved/checked window summaries')
        except Exception as err:
            print(f'FAILED summaries: {type(err).__name__}')
    print(f'Completed request batch; data stored locally at {root}')


if __name__ == '__main__':
    main()
