/** Mapping is opt-in. Never silently infer Garmin API response structure. */
import fs from 'node:fs';
import path from 'node:path';
import { validateDay } from '../app/src/validation.mjs';
function arg(name){const i=process.argv.indexOf(name);return i>=0?process.argv[i+1]:null;}
const date=arg('--date'), root=arg('--root')||'../data/raw/garmin', cfgFile=arg('--mapping')||'mapping.example.json', out=arg('--out');
if(!date||!out)throw new Error('Required: --date YYYY-MM-DD --out file.json');
const cfg=JSON.parse(fs.readFileSync(cfgFile,'utf8'));
if(cfg.confirmed !== true) throw new Error('Mapping NICHT bestätigt. Bitte echte Garmin-Felder und Einheiten überprüfen und confirmed=true setzen.');
const base=path.resolve(root,date);
const data={date,sources:['garmin-personal/confirmed-map'],sleep:{},night:{},garmin:{},workouts:[]};
function at(x,p){return p.split('.').reduce((v,k)=>v!=null&&typeof v==='object'?v[k]:undefined,x);}
for(const [field,m] of Object.entries(cfg.fields)){
 if(!/^(sleep|night|garmin)\.[a-zA-Z][a-zA-Z0-9]*$/.test(field))throw new Error('Field not allowed '+field);
 if(!/^[a-z_]+$/.test(m.file))throw new Error('Invalid file alias');
 const src=path.join(base,`${m.file}.json`);
 if(!fs.existsSync(src))continue;
 const raw=JSON.parse(fs.readFileSync(src,'utf8'));
 const n=at(raw,m.path);
 if(n==null)continue;
 if(typeof n!=='number'||!Number.isFinite(n)||typeof m.factor!=='number'||m.factor<=0)throw new Error('Numeric mismatch: '+field);
 const [section,k]=field.split('.');
 data[section][k]=Math.round(n*m.factor*100)/100;
}
validateDay(data);
fs.writeFileSync(out,JSON.stringify(data,null,2),{mode:0o600,flag:'wx'});
console.log(`Confirmed mapping result written: ${out} (do not commit or publish).`);
