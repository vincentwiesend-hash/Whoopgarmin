# Vergleich NOOP (`noop-main.zip`) ↔ PulseForge Garmin Lab

**Vergleichsstand:** 28.10.2026. Ausgewertet wurde das vom Nutzer bereitgestellte NOOP-Archiv und unser bestehendes PulseForge-Garmin-Projekt. Die gemergte Version ist eine **eigenständige JavaScript-Implementierung**. Nicht als Bevel-/NOOP-Original zu verstehen.

## 1. Grundlegende Unterschiede

| Dimension | NOOP (hochgeladen) | PulseForge zuvor | Entscheidung für gemeinsame Version |
|---|---|---|---|
| Zielhardware | WHOOP 4.0/5.0 per direkter BLE-Kommunikation | Garmin fēnix 7/8/9 über Connect IQ und Garmin Connect | Garmin bleibt primär. **Kein** WHOOP-Protokoll auf Garmin übertragen |
| Plattform | macOS SwiftUI, Android Kotlin, Swift Packages; iOS teilweise vorbereitet | Node.js-Webdashboard + Monkey C Uhren-App | Webdashboard und Garmin-Anbindung bleiben, unabhängige Analytics auf Server |
| Historische Daten | Lokale Datenbank, WHOOP/Apple Health Imports | Garmin Personal API Export plus bestätigtes JSON-Mapping | Quelltreue, Offline-Speicherung und bewusstes Daten-Mapping |
| Physiologische Scores | Dokumentierte eigene Näherungsverfahren, teils noch nur Bibliothekscode | Transparente experimentelle Recovery-, Schlaf- und Trainingslastwerte | Vorhandene transparenten Modelle behalten, nicht NOOP-/Bevel-Werte behaupten |
| Analyse | Metriken-Explorer, Korrelationen, Verhaltenstrends, Zeitfenster | Nur Tagesansicht und Platzhaltertrend | **Implementiert:** echte Trends, Korrelation, Wochenunterschiede, Datenabdeckung |
| Datenschutz | Offline-first ohne Herstellercloud für direkter WHOOP-BLE-Pfad | Lokal betriebener API-Server; Garmin Connect für Historie | Bei Garmin kein vergleichbares vollständiges Cloud-freies Verfahren behaupten |
| Live-Daten | WHOOP-BLE-Stream am Desktop | Zeitweilige Connect-IQ-Uploads | Letzten Garmin-Snapshot darstellen; **kein** Live-/Sekundenstream versprechen |
| Breathing/Haptik/Timer | Spezifisch WHOOP-Motor und eigene BLE-Kommandos | Connect-IQ-Prototyp | Nicht übernommen; UI/Timer wären separat für Garmin SDK zu entwickeln |
| Lizenz | Im hochgeladenen Archiv **keine explizite LICENSE-Datei** gefunden | Eigenständiger Code | Keinen NOOP-Quellcode, keine Icons und keine Assets übernehmen; Idee/faktische Funktionen neu umsetzen |

## 2. Was konkret umgesetzt wurde

1. `app/src/analytics.mjs`: rein funktionale, testbare Deskriptivanalysen über kanonische Garmin-Tagesdaten; 10 Metriken, Korrelation bei mindestens 7 Paaren, fehlertolerante 7-vs.-7-Tage-Trends (mindestens 5 Datenpunkte pro Zeitraum), vollständige kalendarische Tage mit Nullwerten für Datenlücken.
2. `app/server.mjs`: authentifizierter `/api/v1/analytics`-Endpunkt; feste Zeitfenster 7/14/28/42/90 Tage; Metrik-Whitelist; vorhandener Garmin-/Watch-Upload bleibt kompatibel.
3. `app/public/`: zusätzliche Ansichten **Trends**, **Vergleichen**, **Erkenntnisse**, Diagramme aus realen Messreihen und Snapshot-Anzeige des letzten Garmin-Uploads. Demo-Kurven sind ausdrücklich synthetisch gekennzeichnet.
4. `app/src/scoring.mjs`: Cardio Load korrigiert: fehlende Tage oder fehlende Workout-Listen dürfen NICHT als Ruhetag mit Trainingslast 0 interpretiert werden.
5. Tests: arithmetische Grenzfälle, fehlende Tage, fehlende Recovery-Baseline, Authentifizierung, Uhren-Upload-Duplikate und Analytics-API.

## 3. Was bewusst NICHT übernommen wurde

- NOOPs Reverse-Engineering des WHOOP-BLE-Protokolls, WHOOP-Entschlüsselung, proprietäre Gerätesteuerung und WHOOP-Haptik sind nicht kompatibel mit Garmin.
- Keine SwiftUI-/Android-Binaries und keine UI-Assets. Keine automatisierte Übernahme von Drittanbieter-Quellcode ohne geklärte Lizenz.
- Keine Übernahme von NOOPs nicht durchgängig in seinen Apps verdrahteten HRV-/Schlaf-/Recovery-Analyzern als angeblich „bewiesene“ Produktionsimplementierungen. Für Garmin fehlen über die bestehenden APIs gegebenenfalls Roh-RR-Intervalle und Schlaf-Rohbewegungen.
- Kein medizinisches Warnsystem aus schwankender HRV und kein individuelles Krankheitsrisiko; rein deskriptive Aussagen.
- Keine Behauptung, dass die Ergebnisse exakt denen von Bevel, NOOP, WHOOP oder Garmin entsprechen.

## 4. Sinnvolle nächste technische Schritte

1. Echte Garmin Personal API Rohantworten für ein paar Nächte und Trainings verifizieren; JSON-Feldpfade und Einheiten unter Fixture-Tests bestätigen.
2. Tageszeit und Schlafzuordnung pro Zeitzone, Sensor-/Importpriorität und rückwirkende Korrekturen sauber modellieren.
3. SQLite/PostgreSQL mit Datensatzherkunft und unveränderbarer Rohdaten-Provenienz statt der momentanen privaten JSON-Prototypspeicherung.
4. Connect-IQ-Projekt gegen exakte Garmin fēnix Modellnummer und Firmware im Garmin-SDK bauen und auf Hardware testen; offline Retry, Settings und Token-Verwaltung vervollständigen.
5. Optionale Plattformdatenimporte (Apple Health/Health Connect) unabhängig vom WHOOP-Protokoll, ausdrücklich mit Nutzereinwilligung.
6. Danach Krafttraining-Editor, Trainingsbibliothek, Journal und KI-Coach ergänzen; klare Trennung von Messwerten, Heuristiken und Empfehlungen.

## 5. Grenzen und Datenschutz

Diese Version ist ein **lokaler Forschungs- und Entwicklungskern**, keine produktionsreife Gesundheitsplattform. Secrets niemals in Git laden; bestehende Watch-`Config.mc` enthält nur Platzhalter. Die Read- und Admin-Tokens sind für eine einzelne lokal betriebene Installation gedacht. Ohne Nutzerlogin, sichere zentrale Speicherung, TLS-Termination, Backup-Konzept, Rollenmodell, Aufbewahrungs- und Löschfunktionen nicht für fremde Benutzer ausrollen.

Der NOOP-Upload wurde nicht in das Ergebnisarchiv kopiert. Er diente ausschließlich als Referenz für die Funktions- und Architekturentscheidung. Die Quellenlage zur Lizenz kann sich außerhalb des Uploads unterscheiden; daraus leiten wir keine Kopierfreigabe ab.
