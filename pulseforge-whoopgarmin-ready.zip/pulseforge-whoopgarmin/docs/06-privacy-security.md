# 06 · Datenschutz, Sicherheit und klinische/Wellness-Abgrenzung

## Bedrohungsmodell

Betroffene Objekte: persönliche Garmin-Keys, OAuth2-Token, GPS-/Standortverläufe, Trainings-/Gesundheitsdaten, Laborberichte, Ernährung und sensible Journalnotizen. Bedrohungen: fremde Zugriffe, Token-Exfiltration von der Uhr, versehentliche Publikation, fehlerhafte Mandantentrennung, Sync-Duplikate, falsche Scoreinterpretation, unkontrollierte Cloud-Log-Ausgaben.

## Unabdingbare Schutzmaßnahmen vor öffentlichem Produktbetrieb

1. **Datenminimierung:** nur erlaubte Datentypen und explizite Einwilligung; nicht jede FIT-Koordinate erfassen, wenn für Scores nicht nötig.
2. **Zugangsdaten:** Garmin Personal API Key ausschließlich serverseitig, optional Vault/KMS; Rotation, Widerruf, sichere Files `0600`; nie im Git, nie Browser, nie Uhr.
3. **Uhren-Upload:** restriktiver, widerrufbarer Schreib-Token je Gerät mit Token-Rotation, Ratelimits und Missbrauchserkennung; Watch-Token als potenziell extrahierbar behandeln.
4. **Transport:** immer TLS; Backend hinter Reverse Proxy; mTLS sofern sinnvoll; keine „self-signed cert disabled“ Umgehungen.
5. **Speicherung:** PostgreSQL mit Backups/Encryption-at-rest, konkrete Löschfristen, Zugriffsprotokoll, Transaktions- und Duplikatsicherheit.
6. **Mandanten:** User-Identity ausschließlich aus sicherer Session, Row-Level Security oder strikt getrennte Queries; IDOR-Tests und Ownership-Checks.
7. **DSGVO:** Gesundheitsdaten können besonders geschützte personenbezogene Daten nach Art. 9 DSGVO sein. Rechtsgrundlage, Einwilligung/ggf. Ausnahmen, Verarbeitungsverzeichnis, Auftragsverarbeitung, Lösch-/Auskunftsrechte und ggf. DSFA klären; hierzu qualifizierte Rechtsprüfung einholen.
8. **KI-Modul:** keine unkontrollierte Übermittlung von Gesundheitsakten an Dritte; Opt-in, Datenminimierung, Sichtbarkeit externer Anbieter, Audit und keine Diagnosen aus Wellness-Scores.
9. **Klinische Abgrenzung:** Trainings- und Wellness-Feedback ist nicht automatisch Medizinprodukt. Zweckbestimmung, klinische Behauptungen, Nutzergruppe und EU-MDR-Risiken prüfen; ohne Validierung keine klinischen Empfehlungen oder „gesund/krank“-Entscheidungen ableiten.
10. **Offenheit:** Modellversion und Grenzen, Messlücken, Tageszeitzone, Herkunft der Werte, Unsicherheiten immer nachvollziehbar anzeigen.

## Sicherheitsstatus dieses Pakets

- Backend standardmäßig nur an `127.0.0.1` gebunden, getrennte Upload/Admin/Read-Token, konstante Zeit bei Tokenvergleich, maximale Requestgröße und einfache Feldvalidierung.
- Statische Website mit einer einschränkenden CSP, kein Tracking, keine Cloud-SDKs, kein eingebautes fremdes Bevel-Material.
- **Nicht production-ready:** eine lokale JSON-Datei, keine externe Benutzerverwaltung, Token im Browser für lokalen Zugriff, keine Datenverschlüsselung auf Anwendungsebene, keine Access-Logs/Job-Queue, kein Penetrationstest.
- Für die Uhr muss das Geräteverhalten und Token-/Speicherbudget separat getestet werden.
