# 07 · Umsetzung, Abnahmekriterien & Bevel-Black-Box-Validierung

## Reihenfolge und überprüfbare Deliverables

### Phase A · Datenzugang / Schema (höchste Priorität)

1. Exakte fēnix Hardwarekennung, Firmware und Sensor-/Garmin-Connect-Einstellungen dokumentieren.
2. Eigener Garmin Personal API Key auf Garmin Connect Web; Python Client starten; lokale Rohdaten einer Nacht und eines Workouts ablegen.
3. JSON-Feldpfade und Einheiten an realen Rohantworten bestätigen; Mappings per Fixture testen.
4. Datenmodell mit UTC-Zeit, Zeitzone, Nachtzuordnung und Source-Priorität; Postgres migrieren.

**Definition of Done:** Ein echter Schlafreport + HRV + RHR + Aktivität ergibt einen validierten kanonischen Tagesdatensatz, jeder Wert ist auf den Raw-API-Aufruf zurückführbar, keinerlei Einheitenverwechslung.

### Phase B · Score Engine und Dashboard

1. Nacht-Baseline mit 14–60 gültigen Tagen, zeitlicher Datenabdeckung und Ausreißerregeln.
2. Score-Versionierung und Recompute nach Datenrevision.
3. Trendchart und tägliche Score-Komponenten mit pro-Source-Qualität.
4. Alternative Score-Metriken / Kalibration anhand dokumentierter Längsschnittdaten.

**DoD:** Score-Unit-Tests inklusive DST, Reisen, Missing HRV, Neuimport, Duplikate, Gerätetausch. Keine Zahlen bei Missing-Baseline.

### Phase C · Watch-App, Workout-Details und Strength

1. Monkey-C-Gerätebuild pro tatsächlichem Zielgerät, Garmin-Simulator und Hardware-Test; Speicherlimit beobachten.
2. Manueller HTTPS-Upload, Retries/Offlinequeue und Auth; Server-Ingest bewusst idempotent.
3. FIT Import + Workout Merge, keine doppelten Workouts aus API/Watch/Apple Health.
4. Eigener Krafttrainingseditor mit Workout-Plänen, Satztypen, Live-Timer, PRs, Muskelkarten.

**DoD:** eine Woche zuverlässiger Nachsync unter Bluetooth-Ausfällen; nachvollziehbares Fehler-/Retryprotokoll; ein Krafttraining end-to-end.

### Phase D · Vollständige Bevel-ähnliche Funktionalität

Nutrition Foodlog + Produktdatenbank und Prüfbarkeit; Journal; Health Records; eigene Biomarker/biologisches Alter nur nach Modellvalidierung; optional KI-Coaching mit Opt-in; Business Garmin APIs für fremde Nutzer; Barrierefreiheit/Datenschutz/Kommerzialität.

## Clean-Room-Black-Box-Validierung

- Vergleich ausschließlich mit **selbst autorisiert beobachteten** Bevel-Anzeigen und Garmin-Daten, nicht App-Binärdateien, versteckte Token oder private Infrastruktur bearbeiten.
- Paare mit gleichem Aufwachdatum, gleichem Device und gleichem Quellsetting erfassen.
- Pro Tag notieren: Bevel Sleep/Recovery/Strain/Target Strain/Energy, Garmin HRV/RHR/Schlaf/Workout, Uhr-Synczeit und Quellenstatus.
- Kontrollierte Szenarien: anstrengender Trainingstag, Ruhetag, wechselnder HRV, fehlender Schlaf, Schlaf nach Mitternacht, Fitnessgerätwechsel, korrigiertes Training, 2 gleiche Workouts aus verschiedenen Quellen.
- Korrelationen und Fehler getrennt pro Metrik/Untergruppe statt globales „99% genau“.
- Kein Modellgewichts-Tuning auf dieselben Tage, auf denen Genauigkeit demonstriert wird (separates Holdoutfenster).
- Bevel ist kein Goldstandard für physiologische Wahrheit; Reproduzierbarkeit und Plausibilität der eigenen Metrik wichtiger als numerische Übereinstimmung.

## Abnahmetests

| Fall | Erwartetes Verhalten |
|---|---|
| 1 Nacht ohne HRV | Recovery = `null`, fehlender Grund explizit |
| 13 valide Baseline-Nächte | Recovery = `calibrating` |
| 14+ HRV/RHR-Nächte | Recovery berechenbar, plausibler Bereich 0–100 |
| Schlaf falsch in Sekunden interpretiert | Importvalidierung weist unplausible Minuten zurück |
| Derselbe Connect-IQ Upload zweimal | Nur eine Momentaufnahme / eindeutiger Event |
| Garmin Connect Sync verzögert | Letzte Aktualisierung/stale, keine Echtzeitbehauptung |
| Body Battery = 65 | Anzeige „Garmin Body Battery 65“, nicht „Bevel Energy Bank“ |
| 42 vollständige Trainingstage | ATL/CTL und eigene Last berechenbar |
| 14 Tage fehlen beim Training | Cardio-Kalibrierung bleibt offen, keine fiktiven 0-Tage |
| Fremder Nutzer fordert Datensatz an | 401/403, keine privaten Daten |

**Aktueller Teststand:** Node-Code ohne externe Abhängigkeiten; Unit-Tests; noch kein Garmin-Liveaufruf, Watch-Kompilierung oder End-to-End-Echtzeittest.
