# 02 · Architektur: Garmin ↔ Backend ↔ Web-App ↔ Uhr

## Logisches System

```mermaid
flowchart TB
  F[Fenix Wearable] -->|nativer Sync| GC[Garmin Connect]
  F -->|Connect IQ HTTPS optional| Q[Watch Upload Endpoint]
  GC -->|Personal API für EIGENE Daten| P[Raw Import Job]
  P --> R[Immutable raw records]
  Q --> R
  R --> N[Mapping/Normalization]
  N --> D[(PostgreSQL + Timeseries)]
  N --> V[Data quality validation]
  D --> E[Versioned score engine]
  E --> S[Daily score snapshots]
  S --> API[Authenticated API / Web-App]
  D --> API
  API --> UI[Web Dashboard]
  API --> W[Own Connect IQ watch UI]
```

## Garmin-Anbindung 1: Garmin Personal API (Hauptweg)

- Zugriff auf **eigene** Garmin Connect Daten, Pull, eigener Schlüssel aus Garmin Connect Web, OAuth2 Access Token mit ca. 24 h Lebensdauer, keine Refresh-Tokens. Schlüssel bleibt auf dem Server, nicht auf Uhr oder Browser. [S17]
- Offizieller Python-Client `garmin-connect-personal-api-python` liefert Wrapper für Schlaf, HRV, HF-Tageskurve, Steps, Stress, Body Battery, Aktivitätsdaten, Aktivitäten/FIT und Profileinstellungen. [S18]
- `garmin-import/fetch_personal.py` ruft diese Bibliothek für ein explizites Datumfenster auf und speichert **rohe Antworten** lokal. Nicht alle Felder werden von jeder fēnix und Firmware geliefert.
- Die sichere Mapping-Pipeline darf **niemals** „null“ als gemessene 0, Messfehler als gültige Daten oder SDNN als RMSSD behandeln. Die RAW-Struktur ist mit realen Daten zu prüfen, bevor ein Produktions-Mapping erstellt wird.
- Synchronisation ist erst möglich, wenn das Gerät → Garmin Connect erfolgreich abgeschlossen ist; kein Echtzeit-Kanal.
- Bei kommerzieller Mehrbenutzer-App offizielle *Business API* / Starter- oder Enterprise-Zugang, nicht Personal API. [S19]

## Garmin-Anbindung 2: Connect IQ (Zusatz)

- Auf der Uhr laufende Monkey-C-App (Watch-App, Glance oder bei Bedarf Data Field), die zulässige Werte über Communications.makeWebRequest als HTTPS-POST sendet.
- Foreground für manuelle Sync- und Trainingsfunktionen. Hintergrund nur mit Garmin-seitig unterstützten Intervallen/Limitierungen. Ein permanenter 1-Hz-/Live-Stream durch Background ist keine belastbare Annahme.
- Die **genaue** fēnix-7-/8-/9-Hardwarekennung muss mit SDK und echter Uhr geprüft werden. `watch/` enthält nur unkompilierten Quelltext.
- Authentifizierung: widerrufbarer Watch-Upload-Token pro Gerät. Upload erfordert serverseitige Validierung, Sequenz/ID für Duplikate und Offline-Queue für geplante Produktionsversion.
- Zum unmittelbaren Starten/Steuern von Kraftworkouts braucht es eine eigene UI auf Uhr und kompatible Connect-IQ-Funktionen. Garmin Connect Training API kann, bei passendem Business-Zugang, strukturierte Workouts und Kurse ans Garmin-Konto pushen, was nicht dasselbe wie eine direkte Echtzeitsteuerung ist. [S20]

## Kanonische Datenverarbeitung

1. Connector ruft Daten ab → RAW-Objekt, Source-ID, Import-Zeit, API-Endpoint, Datum, Versionskennung.
2. SHA-256/Deduplikation auf `(source, source_record_id, event_type)` bzw. hash + Zeitfenster; Source-Priorität pro Datenart.
3. Quellformat je Source+Schema-Version nach `canonical_measurement` transformieren, Einheiten UTC und lokale Zeitzone separat speichern.
4. QoS: `valid`, `missing`, `stale`, `estimated`, `source_conflict`, `not_supported`; Confidence und Provenance mitgeben.
5. Aktivitätsabgleich: Garmin activity ID / FIT UUID, Startzeit ±1–2 min + Dauer/Disziplin; nicht ohne Konfliktprotokoll automatisch zusammenwerfen.
6. Scores als deterministische Materialisierung je `(day, algorithm_version, data_revision)` schreiben. Korrigierte Rohdaten triggern Rebuild.
7. Frontend stellt sowohl Score, Baseline als auch Datenherkunft und Änderungsstatus dar.

## Zeitkonventionen

- Alle Ereignisse intern in UTC, Anzeige mit per-user-IANA-Timezone (z.B. `Europe/Berlin`), und Source-Zeitzone speichern.
- Nächte gehören zum **Aufwachdatum**. Bevel nutzt eine konfigurierbare Wake-Up-Time als Tagesgrenze. [S4]
- DST (Sommerzeitwechsel), Reise, Nickerchen, Schichtarbeit und Schlaf über Mitternacht müssen Testfälle sein.
- Latest-Snapshot ≠ longitudinaler Verlauf. Garmin Connect Tageswerte können nach Synclauf nachkorrigiert werden.
- Basiswerte nachts nur aus tatsächlich übermittelter Nachtmessung, nicht aus beliebigen Tagesherzfrequenzen ableiten.

## Offline / resilient

- Queue-Jobs wiederholen nur idempotente Anfragen mit exponentiellem Backoff; 429, 5xx, 401 unterschiedlich behandeln.
- Gesundheitsdaten nicht in Logger und Crashreports. Rohdaten verschlüsselt, klar festgelegte TTLs.
- API-Verfügbarkeit / veraltete Daten im UI markieren, nicht als aktuelle Messung ausgeben.
- Bei fehlender HRV **Recovery = null**, nicht null zu 50 ersetzen.
- Für private Einzelnutzung reicht ein lokaler Prozess zum Start; für öffentlich erreichbare Produktion sind DB, User-Auth, Cloud-/VPS-Sicherheit und DSGVO-Artefakte erforderlich.

## Architekturentscheidung

**V1 = Personal API + Web UI; V2 = Connect-IQ-Feature-App; V3 = Business API bei externer Benutzerschaft.** Nicht umgekehrt: Hauptdatenquelle ist Garmin Connect, Uhr-App ist Zusatzinstrument.
