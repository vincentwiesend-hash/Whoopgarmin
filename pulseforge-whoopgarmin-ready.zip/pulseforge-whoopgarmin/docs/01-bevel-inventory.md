# 01 · Funktionales Reverse Engineering: Bevel (öffentlich dokumentierte Funktionen)

**Stichtag 28.10.2026.** Wir vergleichen *beobachtbare Fähigkeiten* und Schnittstellen; keine Kenntnis über private Bevel-Datenbanken, Quellcode oder intern gelernte Modelle. Kennzeichen: **B = öffentlich belegt**, **A = Entwurfsannahme**, **O = offene technische Frage**.

## Produktkonzept

Bevel kombiniert Wearable-Daten, Training, Ernährung, Journal, Biomarker und individualisierte Empfehlungen. Hauptoberfläche: Home mit Tageszusammenfassung; Bereiche Fitness, Journal und Biology; Detailseiten Recovery, Sleep, Strain, Stress & Energy, Nutrition; zusätzlich KI-Assistent. Historische Release-Notizen und aktuelle FAQ zeigen 2026 die Garmin-Integration, Training Plans, erweiterten Strength Builder, Health Records und Biological Age. [S1][S2][S3].

## Vollständiger Funktionskatalog — priorisierte Nachbildung

| Domäne | Beobachtbare Bevel-Funktion | Datenvoraussetzung | Unser Plan | Evidenz |
|---|---|---|---|---|
| Dashboard | Drei Kernringe Strain, Recovery, Sleep; tägliche Einsichten, Timeline, Aktivitätsstatus | Scores, Uhrzeit, Status, Tagesereignisse | eigene Karten / Detailseiten, Verlauf | B [S1, S3] |
| Recovery | 1–100 %, einmal nach Schlaf; Schlaf, nächtliche HRV, RHR, Temperatur, Atmung, SpO₂ | 2+ Nächte, individuell kalibriert | Versioniertes eigenes Modell, missing -> null | B [S4, S5] |
| HRV | Standard RMSSD für unterstützte Apple Watch; Auswahl SDNN/RMSSD; Messfenster konfigurierbar | Roh-IBI oder native HRV, Zeitfenster | Garmin-nächtliche HRV **nicht** mit Apple-RR-Messung gleichsetzen | B [S5] |
| Baseline | 60-Tage-Trends / Vergleich Normal, Above, Below; 2–6 Wochen Kalibration | Nachtwerte 2–6 Wochen | 14 Nachtwerte Mindestzahl + 60-Tage-Fenster, eigene Skalen | B [S4, S6], A eigene Mindestzahl |
| Sleep | Sleep Score, Länge, Tief/REM, Unterbrechungen, Kontinuität, Schlafeffizienz | Garmin Schlafberichte | separates Standardisierungsschema, keine verlorenen Phasen | B [S4, S6] |
| Schlafbedarf | Sleep Need, Sleep Debt, Sleep Bank, Sleep Goal | Schlafhistorie, Ziel | eigenes rolling-debt-Konzept | B [S6] |
| Strain | Aktive Workouts + passive Aktivität, Zone / Dauer, nicht-lineare Summierung | HR über Tag, Aktivitäten, ggf. Kraftdaten | Gewichtete Zonenlast + eigener Log-Proxy | B [S7], A Formel |
| Target Strain | dynamisches Ziel aus Recovery und bisheriger Last | mehrere Tage Erholung/Belastung | nach Kalibration Zielbereich mit Sicherheitsregeln | B [S7, S8] |
| Stress | physiologischer Stress 0–100, nicht gleich mentaler Stress | HRV/HR und Aktivitätskontext | Garmin Stress separat; eigener Stress-Proxy nur nach Validierung | B [S6] |
| Energy Bank | Ladung über Schlaf/Ruhe, Abnahme bei Stress, Übertrag zwischen Tagen | Zeitreihe Schlaf & Stress | zunächst Garmin Body Battery separat, KEINE Umbenennung | B [S6] |
| Fitness | Aktivitäten, Tages/Wochenhistorie, PRs, Aktivitätsdetails, Splits/Intervalle, HF-Zonen | Aktivitäten + ggf. FIT | FIT-Aktivitätsimport und Charts | B [S3] |
| Cardio Load | akut 7 Tage vs chronisch 6 Wochen; Status-Klassen und Kalibration | HR-Workouts, HR-Baseline | ATL/CTL auf dokumentiertem eigenen Lastproxy | B [S9], A Proxy |
| Cardio Focus | Low Aerobic / High Aerobic / Anaerobic | Herzfrequenzzonen | Zeitverteilung und Zone Mapping | B [S3] |
| Strength | Trainingsroutinen, Satztypen, Supersets, Pausen, Progression, Live Sync | Benutzer-Workoutlog | Satz-DB, Workout-Editor, Garmin app optional | B [S10] |
| Muscular Load | 7 Tage / 6 Wochen, Übungsdaten, Gewichte, RPE | Übungsdaten mit Muskelmapping | eigenständige Volumen-/RPE-Analyse | B [S11] |
| Muscle Freshness | Kalibrierung nach 3 Trainingstagen je Muskel, Zustände erholt/ermüdet/leer | Muskelbelastung & Zeit | eigenes Erholungsmodell, ohne medizinische Versprechen | B [S11] |
| Ernährung | Barcode, Foto, Text, Datenbank, Makro/Mikro, eigene Speisen, Rezepte | separate Lebensmitteldatenbank + Nutzer-Logs | Food-Logs und API für offene Food-Datenbank | B [S12] |
| Nutrition Score | 1–100, Lebensmittelqualität & optional Glukose; nicht aus reinen Drittanbieter-Makros | vollständige Mahlzeitenkontexte | v1 nur Nährstoffsumme, Score später | B [S12] |
| Journal | Hydration, Sonnenlicht, Gewohnheiten, Ereignisse | manuelle Logs | Ereignismodell + Eingabeformular | B [S2] |
| Biology | HRV/RHR Baseline, VO₂max, Gewicht, BP, Blutwerte, biologisches Alter | Langzeitdaten/Med-Dokumente | nicht als validierte medizinische Altersberechnung ausgeben | B [S13] |
| Health Records | Labore und Dokumente, erkannte Biomarker, Verlauf | Upload mit hohem Schutzbedarf | Verschlüsselung + expliziter Opt-in + Revision | B [S2] |
| KI | Analysen, Coaching, Pläne, Mahlzeitenauswertung, wiederkehrende Check-ins | freigegebene Daten, regelbasierter Zugriff | optionales Modul mit Evidenzhinweisen & Guardrails | B [S14] |
| Share / Widgets | KPI-Karten und anpassbare Shares, Watch-Komplikationen | UI- und Wearable-Plattform | eigene Branding-Assets | B [S2] |

## Garmin-Sonderfall

Bevel beschreibt direkte Garmin-Connect-Integration, aber bei Garmin: 1 Monat historische Synchronisation, keine HRV tagsüber, Stress/Energy nur aus Herzfrequenz geschätzt, keine Garmin Connect+ Strength/Nutrition-Daten, und nicht alle Änderungen werden zurückgespielt. Live-Herzfrequenz aus Garmin ist in Bevel derzeit **nicht** unterstützt. [S15][S16]

Für uns: Garmin Personal API ist eigene **separate** Integration mit eigenen Nutzungsgrenzen. Das Bevel-Limit „1 Monat Historie“ ist nicht automatisch als technisches Garmin-Personal-API-Limit zu interpretieren.

## Nicht belegbar / nicht zu behaupten

- Exakte Scoregewichte und mathematische Funktionen für Recovery, Sleep, Strain, Energy Bank.
- Bevel-Datenbankschema, privates Backend, Authentifizierungs- und Sync-Implementierung.
- Exakte ML-Parameter für Biological Age und Food-Bildanalyse.
- Geschützte Bevel-Quellcodes, iOS-Binärinformationen, Design-Assets, proprietäre Übungsdatenbank.
- Gleichwertigkeit zwischen Garmin Body Battery, Bevel Energy Bank und experimentellem Energy-Proxy.

## UX-/Verhaltens-Testfragen für echte Black-Box-Prüfung

1. Ändert sich Recovery bei nachgetragenen Schlafdaten rückwirkend?
2. Wie behandelt Bevel Nächte ohne HRV oder mit RHR-Ausreißern?
3. Welche Tagesgrenze wird bei Schichtarbeit, Zeitreisen und Schlaf nach Mitternacht genutzt?
4. Wird Strain als Summe pro Aktivität oder als nichtlineare gemeinsame Funktion angezeigt?
5. Wie verhindert Bevel doppelte Workouts aus Garmin und Apple Health?
6. Wie unterscheiden sich importierte Krafttrainingsaktivitäten von direkt protokollierten Satzlogs?
7. Wie groß ist die Verzögerung zwischen Garmin Connect Sync und Bevel Anzeige?
8. Wie bewertet Bevel Sensordatenlücken? Diese Fragen müssen **gemessen**, nicht geraten werden.

Quellenzuordnung: `08-sources.md`.
