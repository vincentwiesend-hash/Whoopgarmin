# 03 · Scoring und Modellgrenzen

## Quellenbefund: Bevel vs. unabhängige Rekonstruktion

**Bevel öffentlich belegt:**
- Recovery 1–100: Sleep Score, nächtliche HRV/RHR, evtl. Temperatur, Atemfrequenz, SpO₂. Baseline 60 Tage, in der Praxis 2–6 Wochen zur Stabilisierung. [S4][S5][S6]
- Sleep: Dauer relativ zum Schlafbedarf, Tief-/REM-Schlaf, Veränderungen des Schlafpulses, Effizienz und Unterbrechungen; nicht jede Komponente muss verfügbar sein. [S4]
- Strain: aktive + passive Last, Herzfrequenzzonen, Dauer, nichtlinear/logarithmisch; kann über 100 % gehen. [S7]
- Cardio Load: 7-Tage-ATL versus 6-Wochen-CTL; Belastungsmonitor mit Statuskategorien. [S9]
- Energy Bank: über Tage fortgeschriebene Energie, Schlaf/Ruhe lädt auf, Stress senkt. [S6]

**Nicht bekannt:** exakte Formeln, Gewichte, Smoothing, Sonderfallbehandlung, Kalibrationsfunktionen, Modellparameter. Keine wissenschaftliche Gleichwertigkeit behaupten.

## V0.1: exakte **eigene**, überprüfbare Codeformeln

Code: `app/src/scoring.mjs`. Einheit & Version auf jedem Score speichern (`pulseforge-experimental-0.1`). Jeder relevante Input bleibt belegbar.

### Baseline

- Aus den 60 vergangenen Kalendertagen nur **gültige** Werte verwenden.
- Mindestens 14 gültige Vornächte für jeweils HRV und RHR, sonst Recovery **nicht berechnen**.
- Robuster Median `m` und MAD `median(|x-m|)`, Skala `s=max(1.4826*MAD, 0.05*|m|, 0.0001)`.
- Aktuelle Nacht NICHT in den Referenzbereich einrechnen (vermeidet Leckage).

### Sleep Score v0.1

- Benötigt tatsächliche Schlafdauer `T` in Minuten sowie konfigurierten Schlafbedarf `N` (v0.1: Default 480 min).
- `duration = clamp(T/N,0,1)`.
- Falls `inBedMinutes` plausibel vorliegt, `efficiency = clamp(T/inBed,0,1)`.
- `sleep = round(100 * (0.75*duration + 0.25*efficiency))`.
- Fehlt Effizienz, wird nur Dauer verwendet. **Keine Bevel-Spezifikation**, Tief-/REM-Schlaf noch nicht enthalten.
- Eine Nacht über 8 h wird auf 100 % gedeckelt; unzureichend für differenzierte Schlafqualität. Höhere Auflösung erst bei ausreichender validierter Datenbasis.

### Recovery Score v0.1

- Nur mit `sleep`, `HRV_RMSSD`, `RHR` und beiden Baselines.
- `zH = clamp((HRV - medianHRV)/scaleHRV, -2.5, +2.5)`
- `zR = clamp((medianRHR - RHR)/scaleRHR, -2.5, +2.5)`
- `score = round(clamp(60 + 0.38*(10*zH) + 0.32*(10*zR) + 0.30*((sleepScore - 75)*0.6), 0,100))`
- Gewichte **von uns gewählt**, nicht statistisch validiert; bei echter Validierung und Datenqualität ändern.
- Temperatur/SpO₂/Atmung fehlen noch bewusst; Datenqualität sichtbar machen.

### Aktivitäts-Lastproxy und Strain

- Fünf HR-Zonen, Eingabe Minuten pro Zone `[z1,z2,z3,z4,z5]`, alle aus derselben Workouts-Quelle.
- `L = 1*z1 + 2*z2 + 3*z3 + 5*z4 + 8*z5` (gewichtete Zonenminuten).
- Mehrere Workouts eines Tages: `L_total = Summe L_i`.
- Nur *aktiver* Proxy: `Strain = round( clamp(100 * ln(1 + L_total) / ln(1 + 500),0,130) )`.
- Konstante `500` und Gewichte sind **explizit experimentell**. Kein Strain ohne Zone-Minuten; Schritte werden derzeit nicht doppelt zu Workouts addiert.
- **Passive Strain, Muskelbelastung und präzise Target Strain sind noch nicht implementiert**. Anzeige enthält diese Einschränkung.

### Cardio ATL/CTL

- `ATL = Mittelwert(L_t für letzte 7 Kalendertage)`; `CTL = Mittelwert(L_t für letzte 42 Kalendertage)`.
- Null Trainingsbelastung an trainingsfreien Tagen nur, wenn Tag als mit vollständiger Workouterfassung markiert ist.
- Der Prototyp verlangt 42 vorhandene Tageseinträge und für jeden der 42 Tage ein Workout-Array (auch leer); sonst `calibrating`.
- `ratio = ATL/CTL` bei CTL>0. Zustände/Schwellen im Produkt erst nach longitudinaler Kalibrierung.
- Dies ist **kein** validiertes TRIMP oder Bevels unveröffentlichte Cardio-Load-Rechnung.

### Body Battery versus Energy Bank

Garmin Body Battery ist ein eigenständiger herstellerseitig berechneter Score. Bevel Energy Bank ist ein anderes Modell. Im Prototyp heißt das Feld explizit `garminBodyBattery` und wird **nicht** in Bevels Energy Bank umbenannt. Ein eigener Energy-Proxy käme erst nach definiertem State-Space-Modell, Sensorgüte- und Zeitsynchronisationsprüfung.

### Krafttraining v1/v2 Vorschlag

Für jede Übung/Satz `volume = reps × weightKg`; `muscleContribution = volume × muscleActivationWeight`, pro Muskel zuletzt 7 vs 42 Trainingstage. *Muscle Freshness* könnte durch zeitabhängige Lastreduktion via exponentiellem Abbau `F(t)=Σ load_i*exp(-(t-t_i)/τ_muscle)` geschätzt werden. **τ, Muskelgewichte und Interpretation sind frei zu kalibrierende Entwurfswerte, nicht Bevels Formel**. Ohne Satzlogs keine zuverlässige Muskelbelastung aus importierten Garmin-Kraft-Workouts ableiten.

## Validierung vor echtem Einsatz

- Diagnostische Sensitivität/klinische Güte nicht behaupten. Keine Grundlage für individuelle medizinische oder Trainingsfreigabe.
- Golden Fixtures mit erwarteten Werten für vollständige, fehlende, veraltete und unplausible Nächte.
- Benchmark zu ausgewählten Bevel-Tagen ist möglich, **nur mit rechtmäßig zugänglichen eigenen angezeigten Werten** und ohne Kopieren proprietärer Binärlogik; Parameter unverwechselbar/versioniert dokumentieren.
- Messgrößen: MAE und R² Score-Vergleich, Spearman-Trendkorrelation, Anteil `null`, Time-Lag, Score Drift bei Wiederimport. Gleiche Anzeigezahlen sind kein Qualitätsbeweis.
