# 08 · Quellen, alle existierende offizielle Dokumentationen (Abruf 28.10.2026)

Belegkürzel aus den anderen Kapiteln. Bevel-Dokumentation ist **Produktbeschreibung**, keine Veröffentlichung der geheimen Formeln. Garmin-Dokumentation ist Grundlage für unterstützte Schnittstellen, aber ein konkreter Geräte-/Konto-Test bleibt nötig.

- **[S1]** Bevel Produktseite: https://www.bevel.health/de
- **[S2]** Bevel Version/Feature History, zuletzt Stand Oktober 2026: https://help.bevel.health/en/articles/11194113
- **[S3]** Bevel Key Terms / Features: https://help.bevel.health/en/articles/11251073
- **[S4]** Bevel Common Questions (Recovery, Sleep, 60 Tage, 2–6 Wochen): https://help.bevel.health/en/articles/11257601
- **[S5]** Bevel Recovery / HRV / RHR: https://help.bevel.health/en/articles/11258177 und https://help.bevel.health/en/articles/10431233
- **[S6]** Bevel Key Bevel Terms (Stress, Energy, Sleep, Cardio): https://help.bevel.health/en/articles/11251073
- **[S7]** Bevel Strain Common Questions: https://help.bevel.health/en/articles/11257857
- **[S8]** Bevel Strain Performance: https://help.bevel.health/en/articles/14124737
- **[S9]** Bevel Training Load (ATL 7 / CTL 6 Wochen): https://help.bevel.health/en/articles/14206721
- **[S10]** Bevel Strength Builder Fragen: https://help.bevel.health/en/articles/11258753
- **[S11]** Bevel Muskel Load/Freshness: https://help.bevel.health/en/articles/14206849
- **[S12]** Bevel Ernährung: https://help.bevel.health/en/articles/11247745 und https://help.bevel.health/en/articles/11259073
- **[S13]** Bevel Biological Age: https://help.bevel.health/en/articles/11586369
- **[S14]** Bevel Intelligence: https://help.bevel.health/en/articles/11586817
- **[S15]** Bevel Garmin-Integrationsgrenzen: https://help.bevel.health/en/articles/10400449 und https://help.bevel.health/en/articles/11680065
- **[S16]** Bevel Data Sources FAQ zu Garmin-Live-HR: https://help.bevel.health/en/articles/13004417
- **[S17]** Garmin Personal API FAQ / Authentication: https://developer.garmin.com/gc-developer-program/personal/personal-faq
- **[S18]** Garmin offizieller Personal API Python Client / tatsächliche API-Endpunkte: https://github.com/garmin/connect-personal-api-python
- **[S19]** Garmin Connect Developer Program: https://developer.garmin.com/gc-developer-program/overview/
- **[S20]** Garmin Connect Developer Program Training-API- und Connect-IQ-Strategie: https://developer.garmin.com/gc-developer-program/
- Garmin Connect IQ Kommunikations-API: https://developer.garmin.com/connect-iq/api-docs/Toybox/Communications.html
- Garmin Personal API Endpoint Swagger: https://developer.garmin.com/gc-developer-program/personal/swagger-docs
- Garmin Support Personal API: https://support.garmin.com/de-DE/?faq=HfTwLfw1Gn2A7WS1GdAMH8

**Evidenzstatus:** Diese Links belegen die beschriebenen Produktfunktionen und API-Fähigkeiten; sie belegen **nicht** den eigenen Scorealgorithmus. Eigene Formeln sind im Code transparent und als experimentell ausgewiesen.
