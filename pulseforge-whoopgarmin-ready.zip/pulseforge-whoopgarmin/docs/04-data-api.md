# 04 · Kanonisches Datenmodell, APIs & Produktionsschema

## Ziel

Eine **versionsstabile Trennschicht** zwischen Garmin-Spezialfeldern und unserer eigenen App. Rohdaten nicht nur „umbenennen“: Messzeit, Einheit, Source, Aggregationsfenster, Provenance und Revision benötigen eine klare Semantik.

## Minimaler kanonischer Tagesdatensatz (im Demonstrator bereits lauffähig)

```json
{
  "date": "2026-10-28",
  "sources": ["garmin-personal/confirmed-map"],
  "sleep": {
    "asleepMinutes": 455,
    "inBedMinutes": 490,
    "deepMinutes": 91,
    "remMinutes": 105,
    "awakeMinutes": 35
  },
  "night": {"hrvRmssdMs": 54, "restingHeartRateBpm": 51},
  "garmin": {"steps": 8000, "bodyBattery": 72, "stress": 30},
  "workouts": [
    {"type":"run", "zoneMinutes":[8,12,23,7,1]}
  ]
}
```

Alle Zahlen in diesem Beispiel sind **fiktiv**. `date` = Aufwachdatum in lokalem Tageskontext, nicht automatischer UTC-Kalendertag. Die Berechnungs-Engine kann nur `hrvRmssdMs` sinnvoll verwenden; SDNN darf nicht in dieses Feld geschrieben werden. `workouts: []` bedeutet **verifizierte leere Aktivitätsliste** für den Tag; fehlendes `workouts` bedeutet `unknown` und darf nicht automatisch als trainingsfrei gewertet werden.

## Tatsächlich implementierte API-Endpunkte (lokaler Prototyp)

| Methode | Pfad | Auth | Antwort / Zweck |
|---|---|---|---|
| GET | `/healthz` | keine | Healthcheck ohne Gesundheitsdaten |
| POST | `/api/v1/days` | `X-Admin-Token` | validierte normalisierte Tagesdaten speichern |
| GET | `/api/v1/days` | `X-Read-Token` | alle vorhandenen Tage |
| GET | `/api/v1/summary?date=YYYY-MM-DD` | `X-Read-Token` | Tagesdatensatz + berechnete Scores |
| POST | `/api/v1/watch` | `X-Device-Token` | Connect-IQ-Snapshot speichern |
| POST | `/api/garmin/ingest` | `X-Device-Token` | kompatibler Alias für vorherigen Uhren-Code |
| GET | `/api/v1/watch/latest` | `X-Read-Token` | letzter Snapshot |

Browser-Dashboard `GET /`, CSS und JS ausschließlich lokal. Token wird nur im Speicher des geöffneten Browsers gehalten. Demo-Werte erscheinen ohne Token. **Kein produktives Sessionsystem**.

## Garmin-Rohdatenexport & verifiziertes Mapping

- `garmin-import/fetch_personal.py`: offizielle Garmin Bibliothek für Rohdaten. Speicher `data/raw/garmin/YYYY-MM-DD/{sleep,hrv,heart_rate}.json` und Fenster-Summaries beim ersten Datum.
- `inspect_shapes.py`: nur Feldpfade ausgeben, keine Werte (trotzdem sensible Metadaten möglich).
- `mapping.example.json`: **unbestätigte** *Beispielpfade*; absichtlich `confirmed:false`.
- `normalize_confirmed.mjs`: verweigert die Ausgabe, bis die Feldpfade/Einheiten nach echten Antworten bestätigt sind; dann konvertiert es angegebene Faktoren und validiert Datums-/Einheitenbereiche.
- Importer schreibt die API-Daten **nicht** direkt in die App, um falsche HRV- oder Schlaf-Einheiten zu verhindern.
- Nur die bestätigte JSON-Datei wird mit `POST /api/v1/days` importiert.

Beispiel für den manuellen Verifikationsschritt:

```bash
cd garmin-import
python inspect_shapes.py ../data/raw/garmin/2026-10-28/{sleep,hrv,heart_rate}.json
# mapping.example.json KOPIEREN und nach Prüfung Feldpfade + Einheiten setzen,
# confirmed auf true setzen; nicht unkontrolliert auf alles mappen.
node normalize_confirmed.mjs --date 2026-10-28 --mapping mapping.confirmed.json \
  --out /tmp/confirmed-2026-10-28.json
curl -H "X-Admin-Token: $ADMIN_TOKEN" -H 'Content-Type: application/json' \
  -X POST --data-binary @/tmp/confirmed-2026-10-28.json \
  http://127.0.0.1:3477/api/v1/days
```

## Zieldatenmodell PostgreSQL (separat `database/schema.sql`)

- `users`, `data_sources`, `devices`: getrennte Konten und Geräte, Key-Referenzen, Widerruf.
- `raw_ingest_events`: revisionssichere Raw-Texte, Payload-Hash, ID-String, Source, Error/Quarantine.
- `observations`: UTC-Zeit, End-Zeit, Feldname, Wert, Einheit, Fenster, Qualität, Quelle, Versionsstand.
- `sleep_sessions`, `sleep_stages`: Schlaf über Mitternacht; Nächte auf Aufwachdatum beziehen.
- `activities`, `activity_samples`, `exercise_sets`: Garmin-ID, FIT-Referenz, Herzfrequenzzonen, Zeitreihen, Übungsdaten.
- `nutrition_logs`, `journal_entries`: optional, separate nutzerseitige Erfassung.
- `score_snapshots`: Algorithmusversion, Input-Revision, Confidence, Nullgründe, strukturierte Komponenten.
- `audit_events`, `processing_jobs`, `source_preferences`: Herkunft, Duplikate, API-Verzögerungen und Datenexport.

## API-Design für endgültige Web-App

- OAuth/sessionbasierte User-Auth statt READ_TOKEN im Browser; `user_id` aus Session, nicht aus untrusted Query.
- Paginated Data APIs (`cursor`, `limit`), `ETag`, serverseitiger Cache, Ratelimits und getrennte Berechtigungen für Aktivitäten/Labore/Ernährung.
- Historische Revisionsabfrage: „Wieso wurde mein Score vom Dienstag nachträglich verändert?“
- `DELETE /account/export` bzw. klare Export-/Lösch-Workflows nach Authentifizierung; keine öffentlich zugänglichen Raw Dumps.
- Jede Scoreantwort enthält `algorithm_version`, `provenance`, `input_coverage`, `computed_at`, `warnings`.

## Prototypbeschränkungen

- JSON-Datei wird als Ganzes eingelesen/geschrieben, kein gleichzeitiger produktiver Mehrbenutzerbetrieb, keine Transaktionsgarantie, keine Encryption-at-rest, keine Retention-Automation.
- Kein fertiger FIT-Parser, keine Trainingsplan-Push-API, kein Vollimport aus Garmin ohne Mapping-Freigabe.
- Nur für localhost-Test geeignet, **nicht** öffentlich ins Internet stellen ohne zusätzliche Absicherung.
