import fs from 'node:fs';
import path from 'node:path';
import { createStore } from '../app/src/store.mjs';
if(process.env.I_ACKNOWLEDGE_SYNTHETIC_DATA !== 'YES')throw new Error('Set I_ACKNOWLEDGE_SYNTHETIC_DATA=YES to intentionally seed a test-only store');
const target=process.env.DATA_FILE||path.resolve('demo-private.json');
if(fs.existsSync(target))throw new Error('Refuse to overwrite existing data: '+target);
const store=createStore(target);
const records=[];
for(let i=0;i<46;i++){
 const date=new Date(Date.UTC(2026,8,13+i)).toISOString().slice(0,10);
 const day={date,sources:['SYNTHETIC_FIXTURE_NOT_REAL'],sleep:{asleepMinutes:420+(i%8)*9,inBedMinutes:460+(i%8)*9,deepMinutes:75+i%12,remMinutes:90+i%14},night:{hrvRmssdMs:49+(i%8),restingHeartRateBpm:51+(i%6)},garmin:{bodyBattery:50+(i%42),stress:20+(i%15),steps:4500+i%5000},workouts:[{type:'run',zoneMinutes:[10,15,i%23,5,0]}]};
 records.push(day);
}
for(const d of records)store.upsertDay(d);
console.log(`Wrote ${records.length} synthetic daily records to ${target}. NEVER use as real health data.`);
